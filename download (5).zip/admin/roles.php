<?php
require_once __DIR__ . '/../functions.php';
if (!canAccessAdmin()) redirect(SITE_URL);

/* ═══════════ ОБРОБКА ═══════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && checkCsrf($_POST['csrf'] ?? '')) {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'create') {
            $name = trim($_POST['name'] ?? '');
            $slug = trim($_POST['slug'] ?? '');
            if ($name === '') throw new Exception('Введіть назву');
            if ($slug === '') $slug = preg_replace('/[^a-z0-9_]/', '', mb_strtolower($name));
            if (!preg_match('/^[a-z0-9_]{2,50}$/', $slug)) throw new Exception('Slug: 2-50 символів (a-z, 0-9, _)');

            $exists = $pdo->prepare("SELECT id FROM roles WHERE slug = ? OR name = ?");
            $exists->execute([$slug, $name]);
            if ($exists->fetch()) throw new Exception('Роль з таким ім\'ям вже існує');

            $pdo->prepare("INSERT INTO roles (name, slug, color, description, sort_order) VALUES (?,?,?,?,?)")
                ->execute([
                    $name, $slug,
                    $_POST['color'] ?? '#5b6ee1',
                    trim($_POST['description'] ?? ''),
                    (int)($_POST['sort_order'] ?? 0)
                ]);
            $roleId = $pdo->lastInsertId();

            $perms = $_POST['permissions'] ?? [];
            if (is_array($perms)) {
                $ins = $pdo->prepare("INSERT INTO role_permissions (role_id, permission) VALUES (?,?)");
                foreach ($perms as $p) $ins->execute([$roleId, $p]);
            }

            flash('Роль створено', 'success');

        } elseif ($action === 'update') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            if (!$id || $name === '') throw new Exception('Невірні дані');

            $role = $pdo->prepare("SELECT * FROM roles WHERE id = ?");
            $role->execute([$id]);
            $role = $role->fetch();
            if (!$role) throw new Exception('Роль не знайдено');

            if ($role['is_system']) {
                $pdo->prepare("UPDATE roles SET color=?, description=? WHERE id=?")
                    ->execute([
                        $_POST['color'] ?? $role['color'],
                        trim($_POST['description'] ?? ''),
                        $id
                    ]);
            } else {
                $slug = trim($_POST['slug'] ?? $role['slug']);
                if (!preg_match('/^[a-z0-9_]{2,50}$/', $slug)) throw new Exception('Slug невірний');
                $pdo->prepare("UPDATE roles SET name=?, slug=?, color=?, description=?, sort_order=? WHERE id=?")
                    ->execute([
                        $name, $slug,
                        $_POST['color'] ?? '#5b6ee1',
                        trim($_POST['description'] ?? ''),
                        (int)($_POST['sort_order'] ?? 0),
                        $id
                    ]);
            }

            $pdo->prepare("DELETE FROM role_permissions WHERE role_id = ?")->execute([$id]);
            $perms = $_POST['permissions'] ?? [];
            if (is_array($perms)) {
                $ins = $pdo->prepare("INSERT INTO role_permissions (role_id, permission) VALUES (?,?)");
                foreach ($perms as $p) $ins->execute([$id, $p]);
            }

            flash('Роль оновлено', 'success');

        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $role = $pdo->prepare("SELECT * FROM roles WHERE id = ?");
            $role->execute([$id]);
            $role = $role->fetch();

            if (!$role) throw new Exception('Роль не знайдено');
            if ($role['is_system']) throw new Exception('Системну роль не можна видалити');

            $default = $pdo->query("SELECT id FROM roles WHERE slug='user'")->fetchColumn();
            $pdo->prepare("UPDATE users SET role_id = ? WHERE role_id = ?")->execute([$default, $id]);
            $pdo->prepare("DELETE FROM roles WHERE id = ?")->execute([$id]);

            flash('Роль видалено', 'success');
        }
    } catch (Exception $e) {
        flash($e->getMessage(), 'error');
    }

    redirect(SITE_URL . '/admin/roles.php');
}

$roles = $pdo->query("
    SELECT r.*,
      (SELECT COUNT(*) FROM users WHERE role_id = r.id) AS users_count,
      (SELECT COUNT(*) FROM role_permissions WHERE role_id = r.id) AS perms_count
    FROM roles r ORDER BY sort_order, id
")->fetchAll();

$allPerms = allPermissions();
$permGroups = [];
foreach ($allPerms as $key => $p) {
    $permGroups[$p['group']][$key] = $p['name'];
}

$pageTitle = 'Ролі';
require __DIR__ . '/../header.php';
?>

<div class="breadcrumbs">
  <a href="<?= SITE_URL ?>"><?= icon('home', 12) ?> Головна</a>
  <span class="sep">/</span>
  <a href="<?= SITE_URL ?>/admin/index.php">Адмінка</a>
  <span class="sep">/</span>
  <span class="current">Ролі</span>
</div>

<div class="section-head">
  <h1 class="section-title"><?= icon('shield', 18) ?> Ролі та доступи</h1>
  <button class="btn btn-primary btn-sm" id="openCreateRole">
    <?= icon('plus', 15) ?> Нова роль
  </button>
</div>

<div class="admin-nav">
  <a href="<?= SITE_URL ?>/admin/index.php"><?= icon('chart', 14) ?> Дашборд</a>
  <a href="<?= SITE_URL ?>/admin/users.php"><?= icon('users', 14) ?> Користувачі</a>
  <a href="<?= SITE_URL ?>/admin/categories.php"><?= icon('folder', 14) ?> Категорії</a>
  <a href="<?= SITE_URL ?>/admin/subforums.php"><?= icon('grid', 14) ?> Підфоруми</a>
  <a href="<?= SITE_URL ?>/admin/topics.php"><?= icon('file-text', 14) ?> Теми</a>
  <a href="<?= SITE_URL ?>/admin/roles.php" class="active"><?= icon('shield', 14) ?> Ролі</a>
  <a href="<?= SITE_URL ?>/admin/settings.php"><?= icon('settings', 14) ?> Налаштування</a>
</div>

<div class="roles-grid">
  <?php foreach ($roles as $r):
    $perms = getRolePermissions((int)$r['id']);
  ?>
    <div class="role-card" style="--tint: <?= e($r['color']) ?>">
      <div class="role-card-head">
        <div class="role-card-ico"><?= icon('shield', 22) ?></div>
        <div class="role-card-info">
          <div class="role-card-name">
            <?= e($r['name']) ?>
            <?php if ($r['is_system']): ?>
              <span class="role-badge-system" title="Системна"><?= icon('star', 10) ?></span>
            <?php endif; ?>
          </div>
          <div class="role-card-slug">@<?= e($r['slug']) ?></div>
        </div>
      </div>

      <?php if ($r['description']): ?>
        <p class="role-card-desc"><?= e($r['description']) ?></p>
      <?php endif; ?>

      <div class="role-card-stats">
        <div class="role-stat">
          <div class="role-stat-num"><?= (int)$r['users_count'] ?></div>
          <div class="role-stat-lbl">юзерів</div>
        </div>
        <div class="role-stat">
          <div class="role-stat-num"><?= count($perms) ?></div>
          <div class="role-stat-lbl">дозволів</div>
        </div>
      </div>

      <div class="role-card-actions">
        <button type="button" class="role-act-btn primary" data-edit-role="<?= $r['id'] ?>">
          <?= icon('edit', 13) ?> Редагувати
        </button>
        <?php if (!$r['is_system']): ?>
          <button type="button" class="role-act-btn danger" data-delete-role="<?= $r['id'] ?>">
            <?= icon('trash', 13) ?>
          </button>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- ═══════ МОДАЛКА РОЛІ ═══════ -->
<div class="role-modal" id="roleModal">
  <div class="role-modal-box">
    <div class="role-modal-head">
      <h3 id="roleModalTitle"><?= icon('shield', 16) ?> Нова роль</h3>
      <button type="button" class="role-modal-close" data-close-modal><?= icon('x', 16) ?></button>
    </div>

    <form method="post" class="role-modal-form" id="roleForm">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="action" id="roleAction" value="create">
      <input type="hidden" name="id" id="roleId">

      <div class="role-modal-row">
        <label>Назва
          <input type="text" name="name" id="roleName" required maxlength="50">
        </label>
        <label>Slug
          <input type="text" name="slug" id="roleSlug" maxlength="50" pattern="[a-z0-9_]+">
        </label>
      </div>

      <div class="role-modal-row">
        <label>Колір
          <div class="color-input-wrap">
            <input type="color" name="color" id="roleColor" value="#5b6ee1" class="color-input">
            <span class="color-value" id="roleColorValue">#5b6ee1</span>
          </div>
        </label>
        <label>Порядок
          <input type="number" name="sort_order" id="roleSort" value="0">
        </label>
      </div>

      <label>Опис
        <input type="text" name="description" id="roleDesc" maxlength="255">
      </label>

      <div class="role-perms-section">
        <div class="role-perms-head">
          <span class="form-label"><?= icon('settings', 13) ?> Дозволи</span>
          <div class="role-perms-toggle">
            <button type="button" class="role-perms-btn" data-perm-all><?= icon('check', 12) ?> Все</button>
            <button type="button" class="role-perms-btn" data-perm-none><?= icon('x', 12) ?> Нічого</button>
          </div>
        </div>

        <div class="role-perms-list">
          <?php foreach ($permGroups as $group => $perms): ?>
            <div class="role-perm-group">
              <div class="role-perm-group-title"><?= e($group) ?></div>
              <?php foreach ($perms as $key => $label): ?>
                <label class="role-perm-item">
                  <input type="checkbox" name="permissions[]" value="<?= e($key) ?>" data-perm>
                  <span class="role-perm-switch"></span>
                  <span class="role-perm-text"><?= e($label) ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="role-modal-actions">
        <button type="button" class="btn btn-ghost" data-close-modal>Скасувати</button>
        <button type="submit" class="btn btn-primary"><?= icon('check', 15) ?> Зберегти</button>
      </div>
    </form>
  </div>
</div>

<!-- ═══════ МОДАЛКА ВИДАЛЕННЯ ═══════ -->
<div class="role-modal" id="deleteRoleModal">
  <div class="role-modal-box role-modal-box-sm">
    <div class="role-delete-ico"><?= icon('trash', 26) ?></div>
    <h3 class="role-delete-title">Видалити роль?</h3>
    <p class="role-delete-text">
      Роль <b id="deleteRoleName"></b> буде видалено.<br>
      Користувачі з цією роллю отримають роль «Користувач».
    </p>
    <form method="post" id="deleteRoleForm">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="action" value="delete">
      <input type="hidden" name="id" id="deleteRoleId">
      <div class="role-modal-actions">
        <button type="button" class="btn btn-ghost" data-close-modal>Скасувати</button>
        <button type="submit" class="btn btn-danger"><?= icon('trash', 15) ?> Видалити</button>
      </div>
    </form>
  </div>
</div>

<script>
window.ROLE_DATA = <?= json_encode(array_map(function($r) {
    return [
        'id'          => (int)$r['id'],
        'name'        => $r['name'],
        'slug'        => $r['slug'],
        'color'       => $r['color'],
        'description' => $r['description'],
        'sort_order'  => (int)$r['sort_order'],
        'is_system'   => (int)$r['is_system'],
        'permissions' => getRolePermissions((int)$r['id']),
    ];
}, $roles)) ?>;
</script>
<script src="<?= SITE_URL ?>/assets/js/roles.js"></script>

<?php require __DIR__ . '/../footer.php'; ?>