<?php
require_once __DIR__ . '/../functions.php';
if (!canAccessAdmin()) redirect(SITE_URL);

/* ═══════════ ОБРОБКА ФОРМ ═══════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && checkCsrf($_POST['csrf'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $uid    = (int)($_POST['user_id'] ?? 0);

    if (!$uid) {
        flash('Не вказано користувача', 'error');
        redirect(SITE_URL . '/admin/users.php');
    }

    try {
        switch ($action) {

            case 'save':
                $newUsername = trim($_POST['username'] ?? '');
                $newEmail    = trim($_POST['email'] ?? '');
                $newRoleId   = (int)($_POST['role_id'] ?? 0);
                $newBio      = mb_substr(trim($_POST['bio'] ?? ''), 0, 200);
                $newBanned   = isset($_POST['is_banned']) ? 1 : 0;
                $newPassword = $_POST['password'] ?? '';

                if (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $newUsername)) {
                    throw new Exception('Логін: 3-30 символів (a-z, 0-9, _)');
                }
                if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception('Невірний email');
                }
                if (!$newRoleId) {
                    throw new Exception('Оберіть роль');
                }

                // Перевірка ролі
                $roleCheck = $pdo->prepare("SELECT * FROM roles WHERE id = ?");
                $roleCheck->execute([$newRoleId]);
                $newRoleObj = $roleCheck->fetch();
                if (!$newRoleObj) {
                    throw new Exception('Обрана роль не існує');
                }

                $roleSlug = $newRoleObj['slug'];
                if (!in_array($roleSlug, ['user','moderator','admin'], true)) {
                    $roleSlug = 'user';
                }

                // Перевірка унікальності
                $stmt = $pdo->prepare("SELECT id FROM users WHERE (username=? OR email=?) AND id != ?");
                $stmt->execute([$newUsername, $newEmail, $uid]);
                if ($stmt->fetch()) {
                    throw new Exception('Логін або email вже зайняті');
                }

                // Не можна зняти роль admin з себе
                if ($uid === (int)$_SESSION['user_id'] && $newRoleObj['slug'] !== 'admin') {
                    throw new Exception('Не можна зняти роль admin з себе');
                }

                // Оновлення
                if ($newPassword !== '') {
                    if (mb_strlen($newPassword) < 6) {
                        throw new Exception('Пароль мінімум 6 символів');
                    }
                    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                    $pdo->prepare("UPDATE users SET username=?, email=?, role_id=?, role=?, bio=?, is_banned=?, password=? WHERE id=?")
                        ->execute([$newUsername, $newEmail, $newRoleId, $roleSlug, $newBio, $newBanned, $hash, $uid]);
                } else {
                    $pdo->prepare("UPDATE users SET username=?, email=?, role_id=?, role=?, bio=?, is_banned=? WHERE id=?")
                        ->execute([$newUsername, $newEmail, $newRoleId, $roleSlug, $newBio, $newBanned, $uid]);
                }

                // Аватар
                if (!empty($_FILES['avatar']['tmp_name']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
                    $f = $_FILES['avatar'];
                    if ($f['size'] > 2*1024*1024) throw new Exception('Аватар макс 2 МБ');
                    $info = @getimagesize($f['tmp_name']);
                    $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
                    if (!$info || !isset($allowed[$info[2]])) throw new Exception('Тільки JPG/PNG/GIF/WEBP');

                    if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0755, true);
                    $name = 'u' . $uid . '_' . bin2hex(random_bytes(6)) . '.' . $allowed[$info[2]];
                    if (move_uploaded_file($f['tmp_name'], UPLOAD_DIR . $name)) {
                        $old = $pdo->prepare("SELECT avatar FROM users WHERE id=?");
                        $old->execute([$uid]);
                        $oldAvatar = $old->fetchColumn();
                        if ($oldAvatar && file_exists(UPLOAD_DIR . $oldAvatar)) @unlink(UPLOAD_DIR . $oldAvatar);
                        $pdo->prepare("UPDATE users SET avatar=? WHERE id=?")->execute([$name, $uid]);
                    }
                }

                flash('Користувача збережено', 'success');
                break;

            case 'delete':
                if ($uid === (int)$_SESSION['user_id']) {
                    throw new Exception('Не можна видалити себе');
                }
                $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$uid]);
                flash('Користувача видалено', 'success');
                break;

            case 'ban':
                if ($uid === (int)$_SESSION['user_id']) throw new Exception('Не можна забанити себе');
                $pdo->prepare("UPDATE users SET is_banned=1 WHERE id=?")->execute([$uid]);
                flash('Користувача забанено', 'success');
                break;

            case 'unban':
                $pdo->prepare("UPDATE users SET is_banned=0 WHERE id=?")->execute([$uid]);
                flash('Користувача розбанено', 'success');
                break;

            default:
                throw new Exception('Невідома дія');
        }
    } catch (Exception $e) {
        flash($e->getMessage(), 'error');
    }

    redirect(SITE_URL . '/admin/users.php');
}

/* ═══════════ СПИСОК ═══════════ */
$search = trim($_GET['q'] ?? '');
$where  = '';
$params = [];
if ($search !== '') {
    $where = "WHERE u.username LIKE ? OR u.email LIKE ?";
    $params = ['%' . $search . '%', '%' . $search . '%'];
}

$stmt = $pdo->prepare("
    SELECT u.*,
      (SELECT COUNT(*) FROM topics WHERE user_id=u.id AND is_deleted=0) AS topics_count,
      (SELECT COUNT(*) FROM posts WHERE user_id=u.id AND is_deleted=0) AS posts_count
    FROM users u
    $where
    ORDER BY u.created_at DESC
    LIMIT 200
");
$stmt->execute($params);
$users = $stmt->fetchAll();

$allRoles = $pdo->query("
    SELECT r.*,
      (SELECT COUNT(*) FROM users WHERE role_id = r.id) AS users_count
    FROM roles r
    ORDER BY sort_order, id
")->fetchAll();

$pageTitle = 'Користувачі';
require __DIR__ . '/../header.php';
?>

<div class="breadcrumbs">
  <a href="<?= SITE_URL ?>"><?= icon('home', 12) ?> Головна</a>
  <span class="sep">/</span>
  <a href="<?= SITE_URL ?>/admin/index.php">Адмінка</a>
  <span class="sep">/</span>
  <span class="current">Користувачі</span>
</div>

<div class="section-head">
  <h1 class="section-title"><?= icon('users', 18) ?> Користувачі</h1>
  <form method="get" class="admin-search">
    <span class="search-icon"><?= icon('search', 14) ?></span>
    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Пошук за логіном або email...">
    <?php if ($search): ?>
      <a href="?" class="admin-search-clear" title="Очистити"><?= icon('x', 13) ?></a>
    <?php endif; ?>
  </form>
</div>

<div class="admin-nav">
  <a href="<?= SITE_URL ?>/admin/index.php"><?= icon('chart', 14) ?> Дашборд</a>
  <a href="<?= SITE_URL ?>/admin/users.php" class="active"><?= icon('users', 14) ?> Користувачі</a>
  <a href="<?= SITE_URL ?>/admin/categories.php"><?= icon('folder', 14) ?> Категорії</a>
  <a href="<?= SITE_URL ?>/admin/subforums.php"><?= icon('grid', 14) ?> Підфоруми</a>
  <a href="<?= SITE_URL ?>/admin/topics.php"><?= icon('file-text', 14) ?> Теми</a>
  <a href="<?= SITE_URL ?>/admin/roles.php"><?= icon('shield', 14) ?> Ролі</a>
  <a href="<?= SITE_URL ?>/admin/settings.php"><?= icon('settings', 14) ?> Налаштування</a>
</div>

<?php if (!$users): ?>
  <div class="empty">
    <?= icon('users', 32) ?>
    <p>Нічого не знайдено</p>
  </div>
<?php else: ?>

<div class="user-admin-grid">
  <?php foreach ($users as $i => $u):
    // Знаходимо роль користувача
    $userRole = null;
    if (!empty($u['role_id'])) {
        foreach ($allRoles as $rr) {
            if ((int)$rr['id'] === (int)$u['role_id']) { $userRole = $rr; break; }
        }
    }
    if (!$userRole) {
        foreach ($allRoles as $rr) {
            if ($rr['slug'] === ($u['role'] ?? 'user')) { $userRole = $rr; break; }
        }
    }
  ?>
    <div class="user-admin-card <?= $u['is_banned'] ? 'user-banned' : '' ?>"
         style="animation-delay: <?= $i * 0.03 ?>s">

      <div class="user-admin-head">
        <div class="user-admin-avatar">
          <img src="<?= avatarUrl($u) ?>" alt="">
          <?php if ($u['is_banned']): ?>
            <span class="user-admin-status banned" title="Забанено"><?= icon('lock', 11) ?></span>
          <?php elseif ($u['id'] == ($_SESSION['user_id'] ?? 0)): ?>
            <span class="user-admin-status self" title="Це ви"><?= icon('star', 11) ?></span>
          <?php endif; ?>
        </div>
        <div class="user-admin-info">
          <div class="user-admin-name">
            <?= e($u['username']) ?>
            <?php if ($userRole): ?>
              <span class="badge role"
                    style="background:color-mix(in srgb, <?= e($userRole['color']) ?> 15%, transparent); color:<?= e($userRole['color']) ?>">
                <?= e($userRole['name']) ?>
              </span>
            <?php endif; ?>
          </div>
          <div class="user-admin-email"><?= e($u['email']) ?></div>
          <div class="user-admin-meta">
            <span><?= icon('file-text', 10) ?> <?= (int)$u['topics_count'] ?></span>
            <span><?= icon('message', 10) ?> <?= (int)$u['posts_count'] ?></span>
            <span><?= icon('clock', 10) ?> <?= date('d.m.Y', strtotime($u['created_at'])) ?></span>
          </div>
        </div>
      </div>

      <div class="user-admin-actions">
        <button type="button" class="user-act-btn primary"
                data-edit-user="<?= $u['id'] ?>"
                data-username="<?= e($u['username']) ?>"
                data-email="<?= e($u['email']) ?>"
                data-role-id="<?= $userRole ? (int)$userRole['id'] : 0 ?>"
                data-role-name="<?= $userRole ? e($userRole['name']) : '' ?>"
                data-role-color="<?= $userRole ? e($userRole['color']) : '#5b6ee1' ?>"
                data-bio="<?= e($u['bio']) ?>"
                data-avatar="<?= avatarUrl($u) ?>"
                data-banned="<?= $u['is_banned'] ?>"
                data-self="<?= $u['id'] == ($_SESSION['user_id'] ?? 0) ? '1' : '0' ?>">
          <?= icon('edit', 13) ?> Редагувати
        </button>
        <a href="<?= SITE_URL ?>/profile.php?id=<?= $u['id'] ?>" class="user-act-btn" title="Профіль">
          <?= icon('user', 13) ?>
        </a>
        <button type="button" class="user-act-btn danger"
                data-delete-user="<?= $u['id'] ?>"
                data-username="<?= e($u['username']) ?>"
                <?= $u['id'] == ($_SESSION['user_id'] ?? 0) ? 'disabled title="Не можна видалити себе"' : '' ?>>
          <?= icon('trash', 13) ?>
        </button>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php endif; ?>

<!-- ═══════ МОДАЛКА РЕДАГУВАННЯ ═══════ -->
<div class="user-modal" id="editUserModal">
  <div class="user-modal-box">
    <div class="user-modal-head">
      <h3><?= icon('edit', 16) ?> Редагувати користувача</h3>
      <button type="button" class="user-modal-close" data-close-modal><?= icon('x', 16) ?></button>
    </div>

    <form method="post" enctype="multipart/form-data" class="user-modal-form">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="user_id" id="euId">

      <div class="user-modal-avatar-row">
        <div class="user-modal-avatar">
          <img id="euAvatar" src="" alt="">
        </div>
        <label class="user-modal-avatar-label">
          <input type="file" name="avatar" accept="image/*">
          <?= icon('camera', 14) ?> Змінити аватар
        </label>
      </div>

      <div class="user-modal-row">
        <label>Логін
          <input type="text" name="username" id="euUsername" required
                 pattern="[a-zA-Z0-9_]{3,30}" maxlength="30">
        </label>
        <label>Email
          <input type="email" name="email" id="euEmail" required maxlength="120">
        </label>
      </div>

      <div class="user-modal-role-group">
        <span class="form-label">Роль</span>

        <div class="role-picker" id="rolePicker">
          <input type="hidden" name="role_id" id="euRoleId" value="">

          <button type="button" class="role-trigger" data-role-trigger>
            <span class="role-trigger-ico" data-role-icon>
              <?= icon('shield', 16) ?>
            </span>
            <span class="role-trigger-text" data-role-text>Оберіть роль</span>
            <span class="role-trigger-chevron"><?= icon('chevron-down', 14) ?></span>
          </button>

          <div class="role-menu" data-role-menu>
            <?php foreach ($allRoles as $r): ?>
              <button type="button" class="role-item"
                      data-role-value="<?= (int)$r['id'] ?>"
                      data-role-slug="<?= e($r['slug']) ?>"
                      data-role-name="<?= e($r['name']) ?>"
                      data-role-color="<?= e($r['color']) ?>">
                <span class="role-item-ico"
                      style="color:<?= e($r['color']) ?>; background:color-mix(in srgb, <?= e($r['color']) ?> 12%, var(--bg-3)); border-color:color-mix(in srgb, <?= e($r['color']) ?> 30%, var(--border))">
                  <?= icon('shield', 16) ?>
                </span>
                <span class="role-item-body">
                  <span class="role-item-title"><?= e($r['name']) ?></span>
                  <span class="role-item-desc">
                    <?= (int)$r['users_count'] ?> користувачів
                    <?php if (!empty($r['description'])): ?>
                      · <?= e($r['description']) ?>
                    <?php endif; ?>
                  </span>
                </span>
                <span class="role-item-check"><?= icon('check', 14) ?></span>
              </button>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <label>Новий пароль <span class="muted small">(залишити порожнім — не змінювати)</span>
        <input type="text" name="password" placeholder="••••••" minlength="6">
      </label>

      <label>Про себе
        <textarea name="bio" id="euBio" rows="3" maxlength="200"></textarea>
      </label>

      <label class="user-modal-checkbox">
        <input type="checkbox" name="is_banned" id="euBanned">
        <span>Забанити користувача</span>
      </label>

      <div class="user-modal-actions">
        <button type="button" class="btn btn-ghost" data-close-modal>Скасувати</button>
        <button type="submit" class="btn btn-primary"><?= icon('check', 15) ?> Зберегти</button>
      </div>
    </form>
  </div>
</div>

<!-- ═══════ МОДАЛКА ВИДАЛЕННЯ ═══════ -->
<div class="user-modal" id="deleteUserModal">
  <div class="user-modal-box user-modal-box-sm">
    <div class="user-delete-ico"><?= icon('trash', 26) ?></div>
    <h3 class="user-delete-title">Видалити користувача?</h3>
    <p class="user-delete-text">
      Користувача <b id="duName"></b> буде видалено назавжди разом з усіма його темами, постами та лайками. <br>
      <span class="danger-text">Цю дію неможливо скасувати.</span>
    </p>

    <form method="post" id="deleteUserForm">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="action" value="delete">
      <input type="hidden" name="user_id" id="duId">

      <div class="user-modal-actions">
        <button type="button" class="btn btn-ghost" data-close-modal>Скасувати</button>
        <button type="submit" class="btn btn-danger">
          <?= icon('trash', 15) ?> Видалити назавжди
        </button>
      </div>
    </form>
  </div>
</div>

<script>
(function(){
  const $ = id => document.getElementById(id);

  /* ═══ ROLE PICKER (динамічний) ═══ */
  (function(){
    const picker = document.getElementById('rolePicker');
    if (!picker) return;

    const trigger = picker.querySelector('[data-role-trigger]');
    const menu    = picker.querySelector('[data-role-menu]');
    const input   = picker.querySelector('#euRoleId');
    const iconBox = picker.querySelector('[data-role-icon]');
    const textBox = picker.querySelector('[data-role-text]');

    const SHIELD_SVG = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3Z"/></svg>';

    function setRoleById(id, name, color) {
      input.value = id || '';
      textBox.textContent = name || 'Оберіть роль';
      iconBox.innerHTML = SHIELD_SVG;
      iconBox.style.color = color || '';
      iconBox.style.background = color ? `color-mix(in srgb, ${color} 12%, var(--bg-3))` : '';
      iconBox.style.borderColor = color ? `color-mix(in srgb, ${color} 30%, var(--border))` : '';

      menu.querySelectorAll('.role-item').forEach(it => {
        it.classList.toggle('active', parseInt(it.dataset.roleValue) === parseInt(id));
      });
    }

    trigger.addEventListener('click', e => {
      e.stopPropagation();
      picker.classList.toggle('open');
    });

    menu.querySelectorAll('.role-item').forEach(item => {
      item.addEventListener('click', () => {
        setRoleById(
          item.dataset.roleValue,
          item.dataset.roleName,
          item.dataset.roleColor
        );
        picker.classList.remove('open');
      });
    });

    document.addEventListener('click', e => {
      if (!picker.contains(e.target)) picker.classList.remove('open');
    });

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') picker.classList.remove('open');
    });

    window._setRolePickerById = setRoleById;
  })();

  /* ═══ ВІДКРИТТЯ РЕДАКТОРА ═══ */
  document.querySelectorAll('[data-edit-user]').forEach(btn => {
    btn.addEventListener('click', () => {
      const d = btn.dataset;
      $('euId').value       = d.editUser;
      $('euUsername').value = d.username;
      $('euEmail').value    = d.email;
      $('euBio').value      = d.bio;
      $('euAvatar').src     = d.avatar;
      $('euBanned').checked = d.banned === '1';

      if (window._setRolePickerById) {
        window._setRolePickerById(
          d.roleId || 0,
          d.roleName || 'Оберіть роль',
          d.roleColor || '#5b6ee1'
        );
      }

      const modal = $('editUserModal');
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
      setTimeout(() => $('euUsername').focus(), 200);
    });
  });

  /* ═══ ВІДКРИТТЯ ВИДАЛЕННЯ ═══ */
  document.querySelectorAll('[data-delete-user]').forEach(btn => {
    btn.addEventListener('click', () => {
      $('duId').value = btn.dataset.deleteUser;
      $('duName').textContent = btn.dataset.username;

      const modal = $('deleteUserModal');
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  /* ═══ ЗАКРИТТЯ ═══ */
  document.querySelectorAll('[data-close-modal]').forEach(el => {
    el.addEventListener('click', () => {
      el.closest('.user-modal').classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  document.querySelectorAll('.user-modal').forEach(modal => {
    modal.addEventListener('click', e => {
      if (e.target === modal) {
        modal.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.user-modal.open').forEach(m => {
        m.classList.remove('open');
        document.body.style.overflow = '';
      });
    }
  });
})();
</script>

<?php require __DIR__ . '/../footer.php'; ?>