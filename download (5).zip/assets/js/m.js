'use strict';

(function(){
  const $ = s => document.querySelector(s);
  const messages = document.getElementById('dmMessages');
  if (!messages) return;

  const dialogId = parseInt(messages.dataset.dialog);
  const otherId  = parseInt(messages.dataset.other);
  const form     = document.getElementById('dmForm');
  const textarea = form.querySelector('textarea');

  let lastId = 0;
  let loading = false;
  let isFirstLoad = true;

  /* ═══ Загрузка повідомлень ═══ */
  async function loadMessages(){
    if (loading) return;
    loading = true;

    try {
      const res = await fetch(window.SITE_URL + '/api/dm.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'messages',
          dialog_id: dialogId,
          since: lastId,
          csrf: window.CSRF
        })
      });
      const r = await res.json();

      if (r.ok && r.messages) {
        if (isFirstLoad) {
          messages.innerHTML = '';
          isFirstLoad = false;
        }
        r.messages.forEach(m => {
          lastId = Math.max(lastId, m.id);
          appendMessage(m);
        });
        if (r.messages.length) scrollBottom();
      }
    } catch(e){}
    loading = false;
  }

  function appendMessage(m){
    const el = document.createElement('div');
    el.className = 'dm-msg ' + (m.is_mine ? 'mine' : 'theirs');
    el.innerHTML = `
      ${!m.is_mine ? `<img src="${escapeHtml(m.avatar)}" class="dm-msg-avatar" alt="">` : ''}
      <div class="dm-msg-body">
        ${!m.is_mine ? `<div class="dm-msg-name">${escapeHtml(m.username)}</div>` : ''}
        <div class="dm-msg-text">${m.message}</div>
        <div class="dm-msg-time">${escapeHtml(m.time)}</div>
      </div>
    `;
    messages.appendChild(el);
  }

  function scrollBottom(){
    messages.scrollTop = messages.scrollHeight;
  }

  /* ═══ Відправка ═══ */
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const text = textarea.value.trim();
    if (!text) return;

    textarea.value = '';
    textarea.style.height = 'auto';

    try {
      const res = await fetch(window.SITE_URL + '/api/dm.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'send',
          dialog_id: dialogId,
          message: text,
          csrf: window.CSRF
        })
      });
      const r = await res.json();
      if (r.ok) {
        await loadMessages();
      } else if (window.toast) {
        window.toast(r.error || 'Помилка', 'error');
      }
    } catch(e){
      if (window.toast) window.toast('Помилка мережі', 'error');
    }
  });

  /* ─── Авторозмір textarea ─── */
  textarea.addEventListener('input', () => {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  });

  /* ─── Enter = відправити ─── */
  textarea.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      form.dispatchEvent(new Event('submit'));
    }
  });

  function escapeHtml(s){
    return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  /* ═══ Init ═══ */
  loadMessages();
  scrollBottom();

  // Polling кожні 2 секунди
  setInterval(loadMessages, 2000);

})();