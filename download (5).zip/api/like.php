<?php
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Не авторизовано']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
if (!checkCsrf($in['csrf'] ?? '')) {
    http_response_code(403); echo json_encode(['error' => 'CSRF']); exit;
}

$postId = (int)($in['post_id'] ?? 0);
if (!$postId) { echo json_encode(['error' => 'no post']); exit; }

$uid = (int)$_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT id FROM likes WHERE user_id=? AND post_id=?");
$stmt->execute([$uid, $postId]);
if ($stmt->fetch()) {
    $pdo->prepare("DELETE FROM likes WHERE user_id=? AND post_id=?")->execute([$uid, $postId]);
    $liked = false;
} else {
    $pdo->prepare("INSERT INTO likes (user_id,post_id) VALUES (?,?)")->execute([$uid, $postId]);
    $liked = true;
    $author = $pdo->prepare("SELECT user_id FROM posts WHERE id=?");
    $author->execute([$postId]);
    $aid = (int)$author->fetchColumn();
    notify($aid, 'like', 'Ваш пост сподобався!', SITE_URL . "/topic.php?id=" . (int)($in['topic_id'] ?? 0) . "#post-$postId");
}

$c = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE post_id=?");
$c->execute([$postId]);
echo json_encode(['ok' => true, 'liked' => $liked, 'count' => (int)$c->fetchColumn()]);