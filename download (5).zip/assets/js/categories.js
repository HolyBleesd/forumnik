'use strict';

(function(){
  const $ = id => document.getElementById(id);

  /* ═══════════ КАТЕГОРІЯ ═══════════ */
  const catModal = $('catModal');
  const catForm  = $('catForm');

  const subModal = $('subModal');
  const subForm  = $('subForm');

  function clearPerms(form) {
    form.querySelectorAll('.perm-checkbox input').forEach(cb => cb.checked = false);
  }

  function setPerms(form, permsMap) {
    clearPerms(form);
    Object.keys(permsMap || {}).forEach(roleId => {
      (permsMap[roleId] || []).forEach(perm => {
        const cb = form.querySelector(`input[name="role_perms[${roleId}][]"][value="${perm}"]`);
        if (cb) cb.checked = true;
      });
    });
  }

  /* ─── Створити категорію ─── */
  const openCreateCat = $('openCreateCat');
  if (openCreateCat) {
    openCreateCat.addEventListener('click', () => {
      $('catModalTitle').innerHTML = '📁 Нова категорія';
      $('catAction').value = 'create_cat';
      $('catId').value = '';
      catForm.reset();
      clearPerms(catForm);
      catModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  }

  /* ─── Редагувати категорію ─── */
  document.querySelectorAll('[data-edit-cat]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.editCat);
      const cat = (window.CATS_DATA || []).find(c => c.id === id);
      if (!cat) return;

      $('catModalTitle').innerHTML = '✏️ Редагувати категорію';
      $('catAction').value = 'update_cat';
      $('catId').value = cat.id;
      $('catName').value = cat.name;
      $('catDesc').value = cat.description || '';
      $('catColor').value = cat.color;
      $('catSort').value = cat.sort_order;
      $('catHidden').checked = cat.is_hidden === 1;

      catForm.querySelectorAll('input[name="icon"]').forEach(inp => {
        inp.checked = inp.value === cat.icon;
      });

      setPerms(catForm, cat.permissions);

      catModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  /* ─── Створити підкатегорію ─── */
  document.querySelectorAll('[data-add-sub]').forEach(btn => {
    btn.addEventListener('click', () => {
      $('subModalTitle').innerHTML = '🏷 Нова підкатегорія';
      $('subAction').value = 'create_sub';
      $('subId').value = '';
      $('subCatId').value = btn.dataset.addSub;
      subForm.reset();
      clearPerms(subForm);
      subModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  /* ─── Редагувати підкатегорію ─── */
  document.querySelectorAll('[data-edit-sub]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.editSub);
      const sub = (window.SUBS_DATA || []).find(s => s.id === id);
      if (!sub) return;

      $('subModalTitle').innerHTML = '✏️ Редагувати підкатегорію';
      $('subAction').value = 'update_sub';
      $('subId').value = sub.id;
      $('subCatId').value = sub.category_id;
      $('subName').value = sub.name;
      $('subDesc').value = sub.description || '';
      $('subColor').value = sub.color;
      $('subSort').value = sub.sort_order;
      $('subHidden').checked = sub.is_hidden === 1;

      subForm.querySelectorAll('input[name="icon"]').forEach(inp => {
        inp.checked = inp.value === sub.icon;
      });

      setPerms(subForm, sub.permissions);

      subModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  /* ─── Кнопка "Скопіювати з категорії" ─── */
  const copyBtn = $('copyCatPerms');
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const catId = $('subCatId').value;
      if (!catId) return;

      const cat = (window.CATS_DATA || []).find(c => c.id === parseInt(catId));
      if (!cat) {
        if (window.toast) window.toast('Категорію не знайдено', 'error');
        return;
      }

      setPerms(subForm, cat.permissions);

      if (window.toast) {
        window.toast('Дозволи скопійовано з категорії', 'success', 2000);
      }
    });
  }

  /* ═══════════ ЗАКРИТТЯ ═══════════ */
  document.querySelectorAll('[data-close-modal]').forEach(el => {
    el.addEventListener('click', () => {
      el.closest('.role-modal').classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  document.querySelectorAll('.role-modal').forEach(m => {
    m.addEventListener('click', e => {
      if (e.target === m) {
        m.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.role-modal.open').forEach(m => {
        m.classList.remove('open');
        document.body.style.overflow = '';
      });
    }
  });

  /* ─── Колір → текст ─── */
  document.querySelectorAll('.color-input').forEach(inp => {
    inp.addEventListener('input', e => {
      const v = e.target.parentElement.querySelector('.color-value');
      if (v) v.textContent = e.target.value;
    });
  });
})();