'use strict';

(function(){
  const chat = document.getElementById('tgChat');
  if (!chat) return;

  const appealId = parseInt(chat.dataset.appeal);
  const myId     = parseInt(chat.dataset.me);

  const form     = document.getElementById('tgForm');
  const textarea = form ? form.querySelector('textarea') : null;
  const closeBtn = document.getElementById('closeAppeal');
  const typing   = document.getElementById('tgTyping');
  const chatStatus = document.getElementById('chatStatus');

  let lastId = 0;
  let loading = false;
  let firstLoad = true;
  let typingTimer = null;
  let isTypingSent = false;

  /* ═══ Завантаження повідомлень ═══ */
  async function loadMessages(){
    if (loading) return;
    loading = true;

    try {
      const res = await fetch(window.SITE_URL + '/api/appeal.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'messages',
          appeal_id: appealId,
          since: lastId,
          csrf: window.CSRF
        })
      });
      const r = await res.json();

      if (r.ok && r.messages) {
        if (firstLoad) {
          chat.innerHTML = '';
          firstLoad = false;
        }

        let added = false;
        r.messages.forEach(m => {
          lastId = Math.max(lastId, m.id);
          appendMessage(m);
          added = true;
        });

        if (added) scrollToBottom();

        // Оновлюємо статус
        updateStatus(r);
      }
    } catch(e){}
    loading = false;
  }

  /* ═══ Додавання повідомлення ═══ */
  function appendMessage(m){
    const el = document.createElement('div');
    el.className = 'tg-msg ' + (m.is_mine ? 'mine' : 'theirs');
    el.dataset.id = m.id;

    const roleTag = m.is_reviewer && !m.is_mine
      ? '<span class="tg-role">ADMIN</span>'
      : '';

    if (m.is_mine) {
      el.innerHTML = `
        <div class="tg-bubble">
          <div class="tg-text">${m.message}</div>
          <div class="tg-meta">
            <span class="tg-time">${escapeHtml(m.time)}</span>
            <span class="tg-check">✓✓</span>
          </div>
        </div>
      `;
    } else {
      el.innerHTML = `
        <img class="tg-avatar" src="${escapeHtml(m.avatar)}" alt="">
        <div class="tg-bubble">
          <div class="tg-author">
            ${escapeHtml(m.username)}
            ${roleTag}
          </div>
          <div class="tg-text">${m.message}</div>
          <div class="tg-meta">
            <span class="tg-time">${escapeHtml(m.time)}</span>
          </div>
        </div>
      `;
    }

    chat.appendChild(el);
  }

  /* ═══ Прокрутка до низу ═══ */
  function scrollToBottom(smooth){
    const h = chat.scrollHeight;
    if (smooth) {
      chat.scrollTo({ top: h, behavior: 'smooth' });
    } else {
      chat.scrollTop = h;
    }
  }

  /* ═══ Оновлення статусу ═══ */
  function updateStatus(r){
    if (!chatStatus) return;
    if (r.is_typing) {
      if (typing) typing.style.display = 'flex';
      chatStatus.innerHTML = '<span class="appeal-chat-online typing"></span> друкує...';
    } else {
      if (typing) typing.style.display = 'none';
      chatStatus.innerHTML = '<span class="appeal-chat-online"></span> Модератор онлайн';
    }
  }

  /* ═══ Відправка ═══ */
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const text = textarea.value.trim();
      if (!text) return;

      textarea.value = '';
      textarea.style.height = 'auto';

      try {
        const res = await fetch(window.SITE_URL + '/api/appeal.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'send',
            appeal_id: appealId,
            message: text,
            csrf: window.CSRF
          })
        });
        const r = await res.json();
        if (r.ok) {
          await loadMessages();
        } else if (window.toast) {
          window.toast(r.error || 'Помилка', 'error');
        }
      } catch(e){
        if (window.toast) window.toast('Помилка мережі', 'error');
      }
    });

    /* ─── Авторозмір ─── */
    textarea.addEventListener('input', () => {
      textarea.style.height = 'auto';
      textarea.style.height = Math.min(textarea.scrollHeight, 140) + 'px';
      sendTyping();
    });

    /* ─── Enter = відправити ─── */
    textarea.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        form.dispatchEvent(new Event('submit'));
      }
    });
  }

  /* ═══ Повідомлення "друкує" ═══ */
  async function sendTyping(){
    if (isTypingSent) return;
    isTypingSent = true;
    try {
      await fetch(window.SITE_URL + '/api/appeal.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'typing',
          appeal_id: appealId,
          csrf: window.CSRF
        })
      });
    } catch(e){}
    setTimeout(() => { isTypingSent = false; }, 3000);
  }

  /* ═══ Закриття апеляції ═══ */
  if (closeBtn) {
    closeBtn.addEventListener('click', async () => {
      if (!confirm('Закрити апеляцію?')) return;
      try {
        const res = await fetch(window.SITE_URL + '/api/appeal.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'close',
            appeal_id: appealId,
            csrf: window.CSRF
          })
        });
        const r = await res.json();
        if (r.ok) location.reload();
      } catch(e){}
    });
  }

  function escapeHtml(s){
    return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  /* ═══ Init ═══ */
  loadMessages().then(() => scrollToBottom(false));

  // Polling кожні 2 секунди
  setInterval(loadMessages, 2000);
})();