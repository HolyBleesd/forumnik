<?php
require_once __DIR__ . '/../functions.php';
if (!canAccessAdmin()) redirect(SITE_URL);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && checkCsrf($_POST['csrf'] ?? '')) {
    $id     = (int)$_POST['id'];
    $action = $_POST['action'] ?? '';
    if ($action === 'delete')      $pdo->prepare("UPDATE topics SET is_deleted=1 WHERE id=?")->execute([$id]);
    elseif ($action === 'restore') $pdo->prepare("UPDATE topics SET is_deleted=0 WHERE id=?")->execute([$id]);
    elseif ($action === 'pin')     $pdo->prepare("UPDATE topics SET is_pinned = 1 - is_pinned WHERE id=?")->execute([$id]);
    elseif ($action === 'lock')    $pdo->prepare("UPDATE topics SET is_locked = 1 - is_locked WHERE id=?")->execute([$id]);
    flash('OK', 'success');
    redirect(SITE_URL . '/admin/topics.php');
}

$page = max(1, (int)($_GET['page'] ?? 1));
$per  = 20; $off = ($page-1)*$per;

$topics = $pdo->query("
  SELECT t.*, u.username, 
         c.name AS cat_name,
         sf.name AS subforum_name
  FROM topics t 
  JOIN users u ON t.user_id=u.id
  JOIN categories c ON t.category_id=c.id
  LEFT JOIN subforums sf ON t.subforum_id = sf.id
  ORDER BY t.created_at DESC 
  LIMIT $per OFFSET $off
")->fetchAll();

$total = (int)$pdo->query("SELECT COUNT(*) FROM topics")->fetchColumn();

$pageTitle = 'Теми';
require __DIR__ . '/../header.php';
?>
<div class="breadcrumbs">
  <a href="<?= SITE_URL ?>"><?= icon('home', 12) ?> Головна</a>
  <span class="sep">/</span>
  <a href="<?= SITE_URL ?>/admin/index.php">Адмінка</a>
  <span class="sep">/</span>
  <span class="current">Теми</span>
</div>

<h1 class="section-title"><?= icon('file-text', 18) ?> Управління темами</h1>

<div class="admin-nav">
  <a href="<?= SITE_URL ?>/admin/index.php"><?= icon('chart', 14) ?> Дашборд</a>
  <a href="<?= SITE_URL ?>/admin/users.php"><?= icon('users', 14) ?> Користувачі</a>
  <a href="<?= SITE_URL ?>/admin/categories.php"><?= icon('folder', 14) ?> Категорії</a>
  <a href="<?= SITE_URL ?>/admin/subforums.php"><?= icon('grid', 14) ?> Підфоруми</a>
  <a href="<?= SITE_URL ?>/admin/topics.php" class="active"><?= icon('file-text', 14) ?> Теми</a>
  <a href="<?= SITE_URL ?>/admin/roles.php"><?= icon('shield', 14) ?> Ролі</a>
  <a href="<?= SITE_URL ?>/admin/settings.php"><?= icon('settings', 14) ?> Налаштування</a>
</div>

<div class="table-wrap reveal">
  <table class="admin-table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Заголовок</th>
        <th>Автор</th>
        <th>Категорія</th>
        <th>Підфорум</th>
        <th>Статус</th>
        <th>Дії</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($topics as $t): ?>
      <tr class="<?= $t['is_deleted']?'row-deleted':'' ?>">
        <td class="mono"><?= $t['id'] ?></td>
        <td><a href="<?= SITE_URL ?>/topic.php?id=<?= $t['id'] ?>"><?= e($t['title']) ?></a></td>
        <td><?= e($t['username']) ?></td>
        <td class="muted"><?= e($t['cat_name']) ?></td>
        <td class="muted"><?= e($t['subforum_name'] ?? '—') ?></td>
        <td>
          <?php if ($t['is_pinned']): ?><span class="pill warn"><?= icon('pin', 11) ?></span><?php endif; ?>
          <?php if ($t['is_locked']): ?><span class="pill danger"><?= icon('lock', 11) ?></span><?php endif; ?>
          <?php if ($t['is_deleted']): ?><span class="pill danger"><?= icon('trash', 11) ?></span><?php endif; ?>
        </td>
        <td class="actions">
          <form method="post" class="inline-form">
            <input type="hidden" name="csrf" value="<?= csrf() ?>">
            <input type="hidden" name="id" value="<?= $t['id'] ?>">
            <button class="btn btn-ghost btn-sm" name="action" value="pin"><?= $t['is_pinned'] ? icon('pin', 13) : icon('bookmark', 13) ?></button>
            <button class="btn btn-ghost btn-sm" name="action" value="lock"><?= $t['is_locked'] ? icon('lock', 13) : icon('unlock', 13) ?></button>
            <?php if ($t['is_deleted']): ?>
              <button class="btn btn-primary btn-sm" name="action" value="restore"><?= icon('check', 13) ?></button>
            <?php else: ?>
              <button class="btn btn-danger btn-sm" name="action" value="delete" onclick="return confirm('Видалити?')"><?= icon('trash', 13) ?></button>
            <?php endif; ?>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?= paginate($total, $per, $page) ?>
<?php require __DIR__ . '/../footer.php'; ?>