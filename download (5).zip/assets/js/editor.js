'use strict';

/* ═══════════════════════════════════════════════════════════
   PREMIUM WYSIWYG EDITOR
   ═══════════════════════════════════════════════════════════ */

(function(){
  function initEditor(root){
    if (!root || root.dataset.editorInit) return;
    root.dataset.editorInit = '1';

    const area = root.querySelector('[data-editor-area]');
    const toolbar = root.querySelector('[data-editor-toolbar]');
    const hiddenInput = root.querySelector('[data-editor-input]');

    if (!area || !toolbar) return;

    /* ═══ Панель інструментів ═══ */
    toolbar.querySelectorAll('[data-cmd]').forEach(btn => {
      btn.addEventListener('mousedown', e => {
        e.preventDefault();
        const cmd = btn.dataset.cmd;
        const value = btn.dataset.value || null;
        document.execCommand(cmd, false, value);
        area.focus();
        updateActive();
      });
    });

    /* ═══ Формат блоку (h1, h2, p) ═══ */
    toolbar.querySelectorAll('[data-block]').forEach(btn => {
      btn.addEventListener('mousedown', e => {
        e.preventDefault();
        document.execCommand('formatBlock', false, btn.dataset.block);
        area.focus();
        updateActive();
      });
    });

    /* ═══ Шрифт ═══ */
    toolbar.querySelectorAll('[data-font]').forEach(btn => {
      btn.addEventListener('mousedown', e => {
        e.preventDefault();
        document.execCommand('fontName', false, btn.dataset.font);
        area.focus();
      });
    });

    /* ═══ Розмір шрифту ═══ */
    toolbar.querySelectorAll('[data-size]').forEach(btn => {
      btn.addEventListener('mousedown', e => {
        e.preventDefault();
        applyFontSize(area, btn.dataset.size);
        area.focus();
      });
    });

    /* ═══ Колір ═══ */
    toolbar.querySelectorAll('[data-color]').forEach(btn => {
      btn.addEventListener('mousedown', e => {
        e.preventDefault();
        document.execCommand('foreColor', false, btn.dataset.color);
        area.focus();
      });
    });

    /* ═══ Підсвітка ═══ */
    toolbar.querySelectorAll('[data-highlight]').forEach(btn => {
      btn.addEventListener('mousedown', e => {
        e.preventDefault();
        document.execCommand('hiliteColor', false, btn.dataset.highlight);
        area.focus();
      });
    });

    /* ═══ YouTube / Imgur ═══ */
    const openMedia = toolbar.querySelector('[data-open-media]');
    if (openMedia) {
      openMedia.addEventListener('click', () => {
        openMediaModal(root, area);
      });
    }

    /* ═══ Оновлення активної кнопки ═══ */
    function updateActive(){
      toolbar.querySelectorAll('[data-cmd]').forEach(btn => {
        const cmd = btn.dataset.cmd;
        let isActive = false;
        try { isActive = document.queryCommandState(cmd); } catch(e){}
        btn.classList.toggle('active', isActive);
      });
    }

    area.addEventListener('keyup', updateActive);
    area.addEventListener('mouseup', updateActive);
    area.addEventListener('focus', updateActive);

    /* ═══ Синхронізація з прихованим полем ═══ */
    function sync(){
      hiddenInput.value = area.innerHTML;
    }

    area.addEventListener('input', sync);
    area.addEventListener('blur', sync);

    /* ═══ Обробка вставки (без стилів) ═══ */
    area.addEventListener('paste', e => {
      e.preventDefault();
      const text = (e.clipboardData || window.clipboardData).getData('text/plain');
      document.execCommand('insertText', false, text);
    });

    /* ═══ Початковий вміст ═══ */
    if (hiddenInput.value && !area.innerHTML.trim()) {
      area.innerHTML = hiddenInput.value;
    }

    /* ═══ Submit — синхронізація перед відправкою ═══ */
    const form = root.closest('form');
    if (form) {
      form.addEventListener('submit', sync);
    }
  }

  /* ═══ Розмір шрифту через span ═══ */
  function applyFontSize(area, size){
    const sel = window.getSelection();
    if (!sel.rangeCount || sel.isCollapsed) return;

    const range = sel.getRangeAt(0);
    const span = document.createElement('span');
    span.style.fontSize = size + 'px';

    try {
      range.surroundContents(span);
    } catch(e) {
      const fragment = range.extractContents();
      span.appendChild(fragment);
      range.insertNode(span);
    }
    sel.removeAllRanges();
  }

  /* ═══════════════════════════════════════════════════════════
     МОДАЛКА ДЛЯ ВСТАВКИ YOUTUBE / IMGUR
     ═══════════════════════════════════════════════════════════ */
  function openMediaModal(editorRoot, area){
    let modal = document.getElementById('mediaModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mediaModal';
      modal.className = 'media-modal';
      modal.innerHTML = `
        <div class="media-modal-box">
          <div class="media-modal-head">
            <h3>Вставити медіа</h3>
            <button type="button" class="media-modal-close" data-media-close>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
            </button>
          </div>
          <div class="media-modal-tabs">
            <button type="button" class="media-tab active" data-media-tab="youtube">YouTube</button>
            <button type="button" class="media-tab" data-media-tab="imgur">Imgur</button>
            <button type="button" class="media-tab" data-media-tab="link">Посилання</button>
          </div>
          <div class="media-modal-body">
            <div class="media-pane active" data-media-pane="youtube">
              <label>Посилання на YouTube
                <input type="text" data-media-input-youtube placeholder="https://youtube.com/watch?v=...">
              </label>
              <div class="media-preview" data-media-preview-youtube></div>
            </div>
            <div class="media-pane" data-media-pane="imgur">
              <label>Посилання на Imgur або зображення
                <input type="text" data-media-input-imgur placeholder="https://i.imgur.com/... або пряме посилання">
              </label>
              <div class="media-preview" data-media-preview-imgur></div>
            </div>
            <div class="media-pane" data-media-pane="link">
              <label>URL посилання
                <input type="text" data-media-input-link placeholder="https://...">
              </label>
              <label>Текст посилання
                <input type="text" data-media-input-link-text placeholder="Клікніть тут">
              </label>
            </div>
          </div>
          <div class="media-modal-actions">
            <button type="button" class="btn btn-ghost" data-media-close>Скасувати</button>
            <button type="button" class="btn btn-primary" data-media-insert>Вставити</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);

      /* ─── Обробники ─── */
      modal.querySelectorAll('[data-media-close]').forEach(el => {
        el.addEventListener('click', () => modal.classList.remove('show'));
      });
      modal.addEventListener('click', e => {
        if (e.target === modal) modal.classList.remove('show');
      });

      /* Таби */
      modal.querySelectorAll('[data-media-tab]').forEach(tab => {
        tab.addEventListener('click', () => {
          modal.querySelectorAll('[data-media-tab]').forEach(t => t.classList.remove('active'));
          modal.querySelectorAll('[data-media-pane]').forEach(p => p.classList.remove('active'));
          tab.classList.add('active');
          const pane = modal.querySelector(`[data-media-pane="${tab.dataset.mediaTab}"]`);
          if (pane) pane.classList.add('active');
        });
      });

      /* Попередній перегляд YouTube */
      const ytInput = modal.querySelector('[data-media-input-youtube]');
      const ytPrev = modal.querySelector('[data-media-preview-youtube]');
      ytInput.addEventListener('input', () => {
        const id = extractYoutubeId(ytInput.value);
        if (id) {
          ytPrev.innerHTML = `<iframe src="https://www.youtube.com/embed/${id}" frameborder="0" allowfullscreen></iframe>`;
          ytPrev.classList.add('show');
        } else {
          ytPrev.innerHTML = '';
          ytPrev.classList.remove('show');
        }
      });

      /* Попередній перегляд Imgur */
      const imgInput = modal.querySelector('[data-media-input-imgur]');
      const imgPrev = modal.querySelector('[data-media-preview-imgur]');
      imgInput.addEventListener('input', () => {
        const url = extractImageUrl(imgInput.value);
        if (url) {
          imgPrev.innerHTML = `<img src="${url}" alt="">`;
          imgPrev.classList.add('show');
        } else {
          imgPrev.innerHTML = '';
          imgPrev.classList.remove('show');
        }
      });

      /* Вставка */
      modal.querySelector('[data-media-insert]').addEventListener('click', () => {
        const activeTab = modal.querySelector('[data-media-tab].active').dataset.mediaTab;
        let html = '';

        if (activeTab === 'youtube') {
          const id = extractYoutubeId(ytInput.value);
          if (id) {
            html = `<div class="embed-video"><iframe src="https://www.youtube.com/embed/${id}" frameborder="0" allowfullscreen></iframe></div>`;
          }
        } else if (activeTab === 'imgur') {
          const url = extractImageUrl(imgInput.value);
          if (url) {
            html = `<img src="${url}" alt="image" class="embed-image">`;
          }
        } else {
          const url = modal.querySelector('[data-media-input-link]').value.trim();
          const text = modal.querySelector('[data-media-input-link-text]').value.trim() || url;
          if (url) {
            html = `<a href="${url}" target="_blank" rel="noopener">${text}</a>`;
          }
        }

        if (html) {
          area.focus();
          document.execCommand('insertHTML', false, html + '<p><br></p>');
          modal.classList.remove('show');
          ytInput.value = '';
          imgInput.value = '';
          modal.querySelector('[data-media-input-link]').value = '';
          modal.querySelector('[data-media-input-link-text]').value = '';
          ytPrev.innerHTML = '';
          imgPrev.innerHTML = '';
          ytPrev.classList.remove('show');
          imgPrev.classList.remove('show');
        }
      });
    }

    modal.classList.add('show');
  }

  /* ═══ Допоміжні ═══ */
  function extractYoutubeId(url){
    if (!url) return null;
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
      /^([a-zA-Z0-9_-]{11})$/
    ];
    for (const p of patterns) {
      const m = url.match(p);
      if (m) return m[1];
    }
    return null;
  }

  function extractImageUrl(url){
    if (!url) return null;
    const patterns = [
      /(https?:\/\/i\.imgur\.com\/[a-zA-Z0-9]+\.(?:jpg|jpeg|png|gif|webp))/i,
      /(https?:\/\/imgur\.com\/[a-zA-Z0-9]+)/i,
      /(https?:\/\/[^\s]+\.(?:jpg|jpeg|png|gif|webp)(?:\?[^\s]*)?)/i
    ];
    for (const p of patterns) {
      const m = url.match(p);
      if (m) return m[1];
    }
    if (url.startsWith('http') && /\.(jpg|jpeg|png|gif|webp)/i.test(url)) return url;
    return null;
  }

  /* ═══ Ініціалізація всіх редакторів ═══ */
  function initAll(){
    document.querySelectorAll('[data-editor]').forEach(initEditor);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

  window.initEditors = initAll;
})();