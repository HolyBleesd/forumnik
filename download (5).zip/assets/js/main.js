'use strict';

document.addEventListener('DOMContentLoaded', () => {

  /* ═══════════════════════════════════════════════════════════
     DROPDOWN КОРИСТУВАЧА
     ═══════════════════════════════════════════════════════════ */
  const menu = document.getElementById('userMenu');
  if (menu) {
    const btn = menu.querySelector('.user-btn');
    const drop = menu.querySelector('.dropdown');
    btn.addEventListener('click', e => {
      e.stopPropagation();
      drop.classList.toggle('show');
    });
    document.addEventListener('click', () => drop.classList.remove('show'));
  }

  /* ═══════════════════════════════════════════════════════════
     REVEAL ON SCROLL
     ═══════════════════════════════════════════════════════════ */
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (en.isIntersecting) {
          en.target.classList.add('visible');
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.reveal').forEach(el => io.observe(el));
  } else {
    document.querySelectorAll('.reveal').forEach(el => el.classList.add('visible'));
  }

  /* ═══════════════════════════════════════════════════════════
     ЛІЧИЛЬНИКИ
     ═══════════════════════════════════════════════════════════ */
  document.querySelectorAll('.stat-num[data-count]').forEach(el => {
    const target = parseInt(el.dataset.count, 10) || 0;
    if (!target) { el.textContent = '0'; return; }
    const dur = 900;
    const start = performance.now();
    const easeOut = p => 1 - Math.pow(1 - p, 3);
    const step = now => {
      const p = Math.min((now - start) / dur, 1);
      el.textContent = Math.floor(target * easeOut(p)).toLocaleString('uk-UA');
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });

  /* ═══════════════════════════════════════════════════════════
     API HELPER
     ═══════════════════════════════════════════════════════════ */
  async function api(url, data) {
    const res = await fetch(window.SITE_URL + url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ csrf: window.CSRF, ...data })
    });
    return res.json();
  }

  /* ═══════════════════════════════════════════════════════════
     ЛАЙКИ
     ═══════════════════════════════════════════════════════════ */
  document.querySelectorAll('.btn-like').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!window.IS_LOGGED) {
        window.toast('Увійдіть, щоб лайкати', 'error');
        return;
      }
      btn.disabled = true;
      try {
        const r = await api('/api/like.php', { post_id: +btn.dataset.post });
        if (r.ok) {
          btn.classList.toggle('liked', r.liked);
          const c = btn.querySelector('.like-count');
          if (c) c.textContent = r.count;
          const svg = btn.querySelector('svg');
          if (svg) svg.setAttribute('fill', r.liked ? 'currentColor' : 'none');

          btn.animate(
            [{ transform: 'scale(1)' }, { transform: 'scale(1.2)' }, { transform: 'scale(1)' }],
            { duration: 260, easing: 'ease-out' }
          );

          window.toast(
            r.liked ? 'Вподобали пост' : 'Лайк знято',
            r.liked ? 'success' : 'info',
            2000
          );
        } else {
          window.toast(r.error || 'Помилка', 'error');
        }
      } catch {
        window.toast('Помилка мережі', 'error');
      }
      btn.disabled = false;
    });
  });

  /* ═══════════════════════════════════════════════════════════
     МОДЕРАЦІЯ (модалки підтвердження)
     ═══════════════════════════════════════════════════════════ */
  const ACTIONS = {
    'pin': {
      title: 'Закріпити тему?',
      text: 'Закріплена тема завжди буде зверху списку.',
      confirmText: 'Так, закріпити',
      icon: 'question',
      confirmStyle: 'primary',
      toastSuccess: 'Тему закріплено',
    },
    'unpin': {
      title: 'Відкріпити тему?',
      text: 'Тема більше не буде зверху списку.',
      confirmText: 'Так, відкріпити',
      icon: 'question',
      confirmStyle: 'primary',
      toastSuccess: 'Тему відкріплено',
    },
    'lock': {
      title: 'Закрити тему?',
      text: 'Після закриття ніхто не зможе залишати відповіді.',
      confirmText: 'Так, закрити',
      icon: 'warning',
      confirmStyle: 'primary',
      toastSuccess: 'Тему закрито',
    },
    'unlock': {
      title: 'Відкрити тему?',
      text: 'Знову можна буде залишати відповіді.',
      confirmText: 'Так, відкрити',
      icon: 'question',
      confirmStyle: 'primary',
      toastSuccess: 'Тему відкрито',
    },
    'delete-topic': {
      title: 'Видалити тему?',
      text: 'Тему та всі її відповіді буде приховано.',
      confirmText: 'Видалити',
      icon: 'danger',
      confirmStyle: 'danger',
      toastSuccess: 'Тему видалено',
    },
    'delete-post': {
      title: 'Видалити пост?',
      text: 'Повідомлення буде приховано від інших.',
      confirmText: 'Видалити',
      icon: 'danger',
      confirmStyle: 'danger',
      toastSuccess: 'Пост видалено',
    },
  };

  document.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', () => {
      const action = btn.dataset.action;
      const id = +btn.dataset.id;
      const cfg = ACTIONS[action];
      if (!cfg) return;

      let realAction = action;
      if (action === 'pin' && btn.title && btn.title.includes('Відкріпити')) realAction = 'unpin';
      else if (action === 'lock' && btn.title && btn.title.includes('Відкрити')) realAction = 'unlock';

      const real = ACTIONS[realAction] || cfg;

      window.modal({
        title: real.title,
        text: real.text,
        icon: real.icon,
        confirmText: real.confirmText,
        confirmStyle: real.confirmStyle,
        onConfirm: async () => {
          try {
            const r = await api('/api/moderate.php', { action, id });
            if (r.ok) {
              window.toast(real.toastSuccess, 'success', 3000);
              setTimeout(() => {
                if (r.redirect) location.href = r.redirect;
                else location.reload();
              }, 600);
            } else {
              window.toast(r.error || 'Помилка', 'error');
            }
          } catch {
            window.toast('Помилка мережі', 'error');
          }
        }
      });
    });
  });

  /* ═══════════════════════════════════════════════════════════
     РЕАЛЬНИЙ ЧАС КОРИСТУВАЧА
     ═══════════════════════════════════════════════════════════ */
  (function(){
    const els = document.querySelectorAll('[data-local-time]');
    if (!els.length) return;

    const days = ['Нд', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
    const months = ['січ', 'лют', 'бер', 'квіт', 'трав', 'черв', 'лип', 'серп', 'вер', 'жовт', 'лист', 'груд'];

    const update = () => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const ss = String(now.getSeconds()).padStart(2, '0');
      const time = `${hh}:${mm}`;
      const timeFull = `${hh}:${mm}:${ss}`;
      const date = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;

      els.forEach(el => {
        const format = el.dataset.localTime || 'short';
        if (format === 'full')       el.textContent = `${date} · ${timeFull}`;
        else if (format === 'date')  el.textContent = date;
        else                         el.textContent = time;
      });
    };

    update();
    setInterval(update, 1000);
  })();

});