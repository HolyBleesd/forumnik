<?php
require_once __DIR__ . '/../functions.php';
if (!isAdmin()) redirect(SITE_URL);

/* ═══════════ ОБРОБКА ═══════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && checkCsrf($_POST['csrf'] ?? '')) {
    $fields = [
        'social_discord', 'social_tiktok', 'social_youtube', 'social_telegram',
        'social_website', 'social_vk',
        'policy_title', 'policy_content',
        'terms_title',  'terms_content',
        'landing_server_name', 'landing_tagline', 'landing_lore',
        'landing_ip', 'landing_discord_url', 'landing_launcher_url',
        'landing_features',
    ];

    try {
        foreach ($fields as $f) {
            if (isset($_POST[$f])) {
                setSetting($f, trim($_POST[$f]));
            }
        }
        flash('Налаштування збережено', 'success');
    } catch (Exception $e) {
        flash('Помилка: ' . $e->getMessage(), 'error');
    }

    redirect(SITE_URL . '/admin/settings.php');
}

$settings = getAllSettings();
$pageTitle = 'Налаштування';
require __DIR__ . '/../header.php';
?>

<div class="breadcrumbs">
  <a href="<?= SITE_URL ?>"><?= icon('home', 12) ?> Головна</a>
  <span class="sep">/</span>
  <a href="<?= SITE_URL ?>/admin/index.php">Адмінка</a>
  <span class="sep">/</span>
  <span class="current">Налаштування</span>
</div>

<div class="section-head">
  <h1 class="section-title"><?= icon('settings', 18) ?> Налаштування</h1>
</div>

<div class="admin-nav">
  <a href="<?= SITE_URL ?>/admin/index.php"><?= icon('chart', 14) ?> Дашборд</a>
  <a href="<?= SITE_URL ?>/admin/users.php"><?= icon('users', 14) ?> Користувачі</a>
  <a href="<?= SITE_URL ?>/admin/categories.php"><?= icon('folder', 14) ?> Категорії</a>
  <a href="<?= SITE_URL ?>/admin/subforums.php"><?= icon('grid', 14) ?> Підфоруми</a>
  <a href="<?= SITE_URL ?>/admin/topics.php"><?= icon('file-text', 14) ?> Теми</a>
  <a href="<?= SITE_URL ?>/admin/roles.php"><?= icon('shield', 14) ?> Ролі</a>
  <a href="<?= SITE_URL ?>/admin/settings.php" class="active"><?= icon('settings', 14) ?> Налаштування</a>
</div>

<form method="post" class="settings-form">
  <input type="hidden" name="csrf" value="<?= csrf() ?>">

  <!-- ═══ СОЦМЕРЕЖІ ═══ -->
  <div class="settings-card reveal">
    <div class="settings-card-head">
      <div class="settings-card-ico"><?= icon('globe', 20) ?></div>
      <div>
        <h3>Соціальні мережі</h3>
        <p>Вставте посилання на ваші акаунти — іконки автоматично з'являться у футері сайту. Порожні поля не відображаються.</p>
      </div>
    </div>

    <div class="settings-fields">
      <div class="settings-field">
        <div class="settings-field-ico discord"><?= socialIcon('discord', 20) ?></div>
        <div class="settings-field-body">
          <label>Discord</label>
          <input type="url" name="social_discord"
                 placeholder="https://discord.gg/..."
                 value="<?= e($settings['social_discord'] ?? '') ?>">
        </div>
      </div>

      <div class="settings-field">
        <div class="settings-field-ico tiktok"><?= socialIcon('tiktok', 20) ?></div>
        <div class="settings-field-body">
          <label>TikTok</label>
          <input type="url" name="social_tiktok"
                 placeholder="https://tiktok.com/@username"
                 value="<?= e($settings['social_tiktok'] ?? '') ?>">
        </div>
      </div>

      <div class="settings-field">
        <div class="settings-field-ico youtube"><?= socialIcon('youtube', 20) ?></div>
        <div class="settings-field-body">
          <label>YouTube</label>
          <input type="url" name="social_youtube"
                 placeholder="https://youtube.com/@channel"
                 value="<?= e($settings['social_youtube'] ?? '') ?>">
        </div>
      </div>

      <div class="settings-field">
        <div class="settings-field-ico telegram"><?= socialIcon('telegram', 20) ?></div>
        <div class="settings-field-body">
          <label>Telegram</label>
          <input type="url" name="social_telegram"
                 placeholder="https://t.me/username"
                 value="<?= e($settings['social_telegram'] ?? '') ?>">
        </div>
      </div>

      <div class="settings-field">
        <div class="settings-field-ico vk"><?= socialIcon('vk', 20) ?></div>
        <div class="settings-field-body">
          <label>VK</label>
          <input type="url" name="social_vk"
                 placeholder="https://vk.com/username"
                 value="<?= e($settings['social_vk'] ?? '') ?>">
        </div>
      </div>

      <div class="settings-field">
        <div class="settings-field-ico website"><?= icon('globe', 20) ?></div>
        <div class="settings-field-body">
          <label>Веб-сайт</label>
          <input type="url" name="social_website"
                 placeholder="https://example.com"
                 value="<?= e($settings['social_website'] ?? '') ?>">
        </div>
      </div>
    </div>
  </div>

  <!-- ═══ ЛЕНДІНГ ═══ -->
  <div class="settings-card reveal">
    <div class="settings-card-head">
      <div class="settings-card-ico landing"><?= icon('zap', 20) ?></div>
      <div>
        <h3>Головна сторінка (Лендінг)</h3>
        <p>Налаштування для <b>/landing.php</b> — головної сторінки сервера</p>
      </div>
    </div>

    <div class="settings-fields">
      <div class="settings-field">
        <div class="settings-field-body">
          <label>Назва сервера</label>
          <input type="text" name="landing_server_name" maxlength="100"
                 placeholder="NeverDM"
                 value="<?= e($settings['landing_server_name'] ?? 'NeverDM') ?>">
        </div>
      </div>

      <div class="settings-field">
        <div class="settings-field-body">
          <label>Слоган (під назвою)</label>
          <input type="text" name="landing_tagline" maxlength="150"
                 placeholder="Найкращий дм-сервер в Україні"
                 value="<?= e($settings['landing_tagline'] ?? '') ?>">
        </div>
      </div>

      <div class="settings-field">
        <div class="settings-field-body">
          <label>IP сервера</label>
          <input type="text" name="landing_ip" maxlength="100"
                 placeholder="play.neverdm.ua:7777"
                 value="<?= e($settings['landing_ip'] ?? '') ?>">
        </div>
      </div>

      <div class="settings-field">
        <div class="settings-field-body">
          <label>Посилання на Discord</label>
          <input type="url" name="landing_discord_url"
                 placeholder="https://discord.gg/..."
                 value="<?= e($settings['landing_discord_url'] ?? '') ?>">
        </div>
      </div>

      <div class="settings-field settings-field-full">
        <div class="settings-field-body">
          <label>Посилання для завантаження лаунчера</label>
          <input type="text" name="landing_launcher_url" maxlength="255"
                 placeholder="https://example.com/launcher.exe або #launcher"
                 value="<?= e($settings['landing_launcher_url'] ?? '#launcher') ?>">
        </div>
      </div>

      <div class="settings-field settings-field-full">
        <div class="settings-field-body">
          <label>Лор сервера</label>
          <textarea name="landing_lore" rows="6" class="settings-textarea"
                    placeholder="Розкажіть історію сервера..."><?= e($settings['landing_lore'] ?? '') ?></textarea>
          <div class="settings-hint">
            <?= icon('sparkle', 12) ?>
            Розкажіть коротко про сервер — це покажеться на головній
          </div>
        </div>
      </div>

      <div class="settings-field settings-field-full">
        <div class="settings-field-body">
          <label>Переваги (по одному на рядок)</label>
          <textarea name="landing_features" rows="6" class="settings-textarea"
                    placeholder="Фракції та банди&#10;Поліція та спецназ&#10;Роботи та бізнес"><?= e($settings['landing_features'] ?? '') ?></textarea>
          <div class="settings-hint">
            <?= icon('sparkle', 12) ?>
            Кожен рядок — окрема перевага
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ═══ ПОЛІТИКА ═══ -->
  <div class="settings-card reveal">
    <div class="settings-card-head">
      <div class="settings-card-ico policy"><?= icon('lock', 20) ?></div>
      <div>
        <h3>Політика конфіденційності</h3>
        <p>Текст буде показано на сторінці <b>/page.php?slug=policy</b>. Підтримується HTML.</p>
      </div>
    </div>

    <div class="settings-fields">
      <div class="settings-field settings-field-full">
        <div class="settings-field-body">
          <label>Заголовок сторінки</label>
          <input type="text" name="policy_title" maxlength="200"
                 placeholder="Політика конфіденційності"
                 value="<?= e($settings['policy_title'] ?? 'Політика конфіденційності') ?>">
        </div>
      </div>

      <div class="settings-field settings-field-full">
        <div class="settings-field-body">
          <label>Текст політики</label>
          <textarea name="policy_content" rows="14" class="settings-textarea"
                    placeholder="Пишіть текст тут..."><?= e($settings['policy_content'] ?? '') ?></textarea>
        </div>
      </div>
    </div>
  </div>

  <!-- ═══ УМОВИ ═══ -->
  <div class="settings-card reveal">
    <div class="settings-card-head">
      <div class="settings-card-ico terms"><?= icon('file-text', 20) ?></div>
      <div>
        <h3>Умови і правила</h3>
        <p>Текст буде показано на сторінці <b>/page.php?slug=terms</b></p>
      </div>
    </div>

    <div class="settings-fields">
      <div class="settings-field settings-field-full">
        <div class="settings-field-body">
          <label>Заголовок сторінки</label>
          <input type="text" name="terms_title" maxlength="200"
                 placeholder="Умови і правила"
                 value="<?= e($settings['terms_title'] ?? 'Умови і правила') ?>">
        </div>
      </div>

      <div class="settings-field settings-field-full">
        <div class="settings-field-body">
          <label>Текст правил</label>
          <textarea name="terms_content" rows="14" class="settings-textarea"
                    placeholder="Пишіть текст тут..."><?= e($settings['terms_content'] ?? '') ?></textarea>
        </div>
      </div>
    </div>
  </div>

  <div class="settings-actions">
    <button type="submit" class="settings-save-btn">
      <?= icon('check', 16) ?> Зберегти налаштування
    </button>
  </div>
</form>

<?php require __DIR__ . '/../footer.php'; ?>