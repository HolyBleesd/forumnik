<?php
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Не авторизовано']);
    exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
if (!checkCsrf($in['csrf'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF']);
    exit;
}

$action = $in['action'] ?? '';

try {
    switch ($action) {

        case 'create':
            $pid = (int)($in['punishment_id'] ?? 0);
            $msg = trim($in['message'] ?? '');
            if (!$pid || mb_strlen($msg) < 10) throw new Exception('Мінімум 10 символів');

            // Перевірка що покарання належить користувачу
            $stmt = $pdo->prepare("SELECT * FROM user_punishments WHERE id = ? AND user_id = ?");
            $stmt->execute([$pid, $_SESSION['user_id']]);
            if (!$stmt->fetch()) throw new Exception('Покарання не знайдено');

            $aid = createAppeal($pid, (int)$_SESSION['user_id'], $msg);
            echo json_encode(['ok' => true, 'appeal_id' => $aid]);
            break;

        case 'messages':
            $aid = (int)($in['appeal_id'] ?? 0);
            $since = (int)($in['since'] ?? 0);
            if (!$aid) throw new Exception('Невірний ID');

            $appeal = getAppeal($aid);
            if (!$appeal) throw new Exception('Апеляцію не знайдено');

            $isOwner = (int)$appeal['user_id'] === (int)$_SESSION['user_id'];
            $isReviewer = canReviewAppeals();

            if (!$isOwner && !$isReviewer) throw new Exception('Немає доступу');

            $messages = getAppealMessages($aid, $since);
            $out = [];
            foreach ($messages as $m) {
                $out[] = [
                    'id'         => (int)$m['id'],
                    'user_id'    => (int)$m['user_id'],
                    'username'   => $m['username'],
                    'avatar'     => avatarUrl(['username' => $m['username'], 'avatar' => $m['avatar']]),
                    'message'    => $m['message'],
                    'role'       => $m['role'],
                    'is_mine'    => (int)$m['user_id'] === (int)$_SESSION['user_id'],
                    'created_at' => timeAgo($m['created_at']),
                ];
            }
            echo json_encode(['ok' => true, 'messages' => $out, 'status' => $appeal['status']]);
            break;

        case 'send':
            $aid = (int)($in['appeal_id'] ?? 0);
            $msg = trim($in['message'] ?? '');
            if (!$aid || mb_strlen($msg) < 1) throw new Exception('Порожнє повідомлення');

            $appeal = getAppeal($aid);
            if (!$appeal) throw new Exception('Апеляцію не знайдено');
            if ($appeal['status'] === 'closed') throw new Exception('Апеляція закрита');

            $isOwner = (int)$appeal['user_id'] === (int)$_SESSION['user_id'];
            $isReviewer = canReviewAppeals();
            if (!$isOwner && !$isReviewer) throw new Exception('Немає доступу');

            $pdo->prepare("INSERT INTO appeal_messages (appeal_id, user_id, message) VALUES (?,?,?)")
                ->execute([$aid, $_SESSION['user_id'], $msg]);

            // Сповіщення
            if ($isOwner) {
                // Сповістити всіх ревʼюверів — поки просто перший
                notify((int)$appeal['user_id'], 'appeal_reply', 'Нове повідомлення в апеляції', SITE_URL . '/appeal.php?id=' . $aid);
            } else {
                notify((int)$appeal['user_id'], 'appeal_reply', 'Модератор відповів в апеляції', SITE_URL . '/appeal.php?id=' . $aid);
            }

            $mid = (int)$pdo->lastInsertId();
            echo json_encode(['ok' => true, 'message_id' => $mid]);
            break;

        case 'close':
            $aid = (int)($in['appeal_id'] ?? 0);
            if (!canReviewAppeals()) throw new Exception('Немає прав');
            $pdo->prepare("UPDATE appeals SET status = 'closed', closed_at = NOW(), closed_by = ? WHERE id = ?")
                ->execute([$_SESSION['user_id'], $aid]);
            echo json_encode(['ok' => true]);
            break;

        default:
            throw new Exception('Невідома дія');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}