<?php
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isModerator()) {
    http_response_code(403); echo json_encode(['error'=>'Forbidden']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
if (!checkCsrf($in['csrf'] ?? '')) {
    http_response_code(403); echo json_encode(['error'=>'CSRF']); exit;
}

$action = $in['action'] ?? '';
$id     = (int)($in['id'] ?? 0);
if (!$id) { echo json_encode(['error'=>'no id']); exit; }

switch ($action) {
    case 'pin':
        $pdo->prepare("UPDATE topics SET is_pinned = 1 - is_pinned WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true]); break;
    case 'lock':
        $pdo->prepare("UPDATE topics SET is_locked = 1 - is_locked WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true]); break;
    case 'delete-topic':
        $pdo->prepare("UPDATE topics SET is_deleted=1 WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true, 'redirect'=>SITE_URL]); break;
    case 'delete-post':
        $uid = (int)$_SESSION['user_id'];
        $stmt = $pdo->prepare("SELECT user_id FROM posts WHERE id=?");
        $stmt->execute([$id]);
        $owner = (int)$stmt->fetchColumn();
        if (!isModerator() && $owner !== $uid) {
            http_response_code(403); echo json_encode(['error'=>'Forbidden']); exit;
        }
        $pdo->prepare("UPDATE posts SET is_deleted=1 WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true]); break;
    default:
        echo json_encode(['error'=>'unknown action']);
}