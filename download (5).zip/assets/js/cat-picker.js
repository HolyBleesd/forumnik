'use strict';

(function(){
  const tree = window.CAT_TREE || [];
  const picker = document.getElementById('catPicker');
  if (!picker) return;

  const trigger = document.getElementById('catPickerTrigger');
  const iconBox = document.getElementById('catPickerIcon');
  const textBox = document.getElementById('catPickerText');
  const menu = document.getElementById('catPickerMenu');
  const catInput = document.getElementById('catIdInput');
  const subInput = document.getElementById('subIdInput');
  const subfInput = document.getElementById('subfIdInput');

  let selectedCat = null;
  let selectedItem = null;

  /* ═══ Побудова меню ═══ */
  function buildMenu(){
    menu.innerHTML = '';
    tree.forEach(cat => {
      const catBtn = document.createElement('button');
      catBtn.type = 'button';
      catBtn.className = 'cp-cat';
      catBtn.innerHTML = `
        <span class="cp-cat-icon" style="--tint:${cat.color}">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/></svg>
        </span>
        <span class="cp-cat-body">
          <span class="cp-cat-name">${escapeHtml(cat.name)}</span>
          ${cat.desc ? `<span class="cp-cat-desc">${escapeHtml(cat.desc)}</span>` : ''}
        </span>
        <span class="cp-cat-arrow">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
        </span>
      `;
      catBtn.addEventListener('click', () => {
        if (cat.items && cat.items.length) {
          // Показуємо підрозділи
          showSubmenu(cat);
        } else {
          // Одразу вибираємо
          selectCategory(cat, null);
          closeMenu();
        }
      });
      menu.appendChild(catBtn);
    });

    // Кнопка "Назад" у меню
    const backBtn = document.createElement('button');
    backBtn.type = 'button';
    backBtn.className = 'cp-back';
    backBtn.style.display = 'none';
    backBtn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 5l-7 7 7 7"/></svg>
      Назад
    `;
    backBtn.addEventListener('click', () => {
      buildMenu();
      backBtn.style.display = 'none';
    });
    menu.insertBefore(backBtn, menu.firstChild);
  }

  /* ═══ Показати підрозділи категорії ═══ */
  function showSubmenu(cat){
    menu.innerHTML = '';

    const backBtn = document.createElement('button');
    backBtn.type = 'button';
    backBtn.className = 'cp-back';
    backBtn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 5l-7 7 7 7"/></svg>
      Назад
    `;
    backBtn.addEventListener('click', buildMenu);
    menu.appendChild(backBtn);

    // Категорія сама
    const catRow = document.createElement('button');
    catRow.type = 'button';
    catRow.className = 'cp-item cp-item-cat';
    catRow.innerHTML = `
      <span class="cp-item-icon" style="--tint:${cat.color}">
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/></svg>
      </span>
      <span class="cp-item-name">${escapeHtml(cat.name)} <span class="cp-item-hint">(без підрозділу)</span></span>
    `;
    catRow.addEventListener('click', () => {
      selectCategory(cat, null);
      closeMenu();
    });
    menu.appendChild(catRow);

    // Підрозділи
    cat.items.forEach(item => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'cp-item';
      const typeLabel = item.type === 'subforum' ? 'підфорум' : 'підкатегорія';
      btn.innerHTML = `
        <span class="cp-item-icon" style="--tint:${item.color}">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h16M4 15h16M10 3 8 21M16 3l-2 18"/></svg>
        </span>
        <span class="cp-item-name">${escapeHtml(item.name)}</span>
        <span class="cp-item-type">${typeLabel}</span>
      `;
      btn.addEventListener('click', () => {
        selectCategory(cat, item);
        closeMenu();
      });
      menu.appendChild(btn);
    });
  }

  /* ═══ Вибір категорії ═══ */
  function selectCategory(cat, item){
    selectedCat = cat;
    selectedItem = item;

    catInput.value = cat.id;
    subInput.value = (item && item.type === 'sub') ? item.id : '';
    subfInput.value = (item && item.type === 'subforum') ? item.id : '';

    // Оновлюємо тригер
    const color = item ? item.color : cat.color;
    iconBox.style.color = color;
    iconBox.style.background = hexToRgba(color, .12);
    iconBox.style.borderColor = hexToRgba(color, .3);

    iconBox.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/></svg>
    `;

    if (item) {
      textBox.innerHTML = `<b>${escapeHtml(cat.name)}</b> <span class="cp-arrow">→</span> ${escapeHtml(item.name)}`;
    } else {
      textBox.innerHTML = `<b>${escapeHtml(cat.name)}</b>`;
    }

    trigger.classList.add('has-value');
    picker.classList.remove('open');
  }

  /* ═══ Відкриття / закриття ═══ */
  trigger.addEventListener('click', e => {
    e.stopPropagation();
    picker.classList.toggle('open');
  });

  document.addEventListener('click', e => {
    if (!picker.contains(e.target)) picker.classList.remove('open');
  });

  function closeMenu(){
    picker.classList.remove('open');
  }

  /* ═══ Утиліти ═══ */
  function escapeHtml(s){
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function hexToRgba(hex, a){
    hex = hex.replace('#','');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const r = parseInt(hex.substr(0,2),16);
    const g = parseInt(hex.substr(2,2),16);
    const b = parseInt(hex.substr(4,2),16);
    return `rgba(${r},${g},${b},${a})`;
  }

  /* ═══ Ініціалізація ═══ */
  buildMenu();

  // Дропдауни шрифтів
  document.querySelectorAll('[data-dd-trigger]').forEach(tr => {
    tr.addEventListener('mousedown', e => {
      e.preventDefault();
      const name = tr.dataset.ddTrigger;
      const menu = document.querySelector(`[data-dd-menu="${name}"]`);
      if (!menu) return;
      document.querySelectorAll('[data-dd-menu]').forEach(m => {
        if (m !== menu) m.classList.remove('show');
      });
      menu.classList.toggle('show');
    });
  });

  document.addEventListener('mousedown', e => {
    if (!e.target.closest('.re-dropdown')) {
      document.querySelectorAll('[data-dd-menu]').forEach(m => m.classList.remove('show'));
    }
  });

  // Кольори
  document.querySelectorAll('.re-colors').forEach(box => {
    const btn = box.querySelector('.re-color-current');
    const menu = box.querySelector('.re-colors-menu');
    btn.addEventListener('mousedown', e => {
      e.preventDefault();
      document.querySelectorAll('.re-colors-menu').forEach(m => {
        if (m !== menu) m.classList.remove('show');
      });
      menu.classList.toggle('show');
    });
  });

  document.addEventListener('mousedown', e => {
    if (!e.target.closest('.re-colors')) {
      document.querySelectorAll('.re-colors-menu').forEach(m => m.classList.remove('show'));
    }
  });
})();