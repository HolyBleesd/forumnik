'use strict';

(function(){
  const $ = s => document.querySelector(s);
  const $$ = s => document.querySelectorAll(s);

  /* ═══════════════════════════════════════════════════════════
     РЕДАГУВАННЯ ПОСТІВ
     ═══════════════════════════════════════════════════════════ */
  $$('[data-start-edit]').forEach(btn => {
    btn.addEventListener('click', () => {
      const card = btn.closest('.post-card');
      const content = card.querySelector('[data-content]');
      const form = card.querySelector('[data-edit-form]');

      content.style.display = 'none';
      form.style.display = 'block';

      // Ініціалізуємо редактор якщо ще не
      if (window.initEditors) window.initEditors();
    });
  });

  $$('[data-cancel-edit]').forEach(btn => {
    btn.addEventListener('click', () => {
      const card = btn.closest('.post-card');
      const content = card.querySelector('[data-content]');
      const form = card.querySelector('[data-edit-form]');
      content.style.display = '';
      form.style.display = 'none';
    });
  });

  $$('[data-save-edit]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const card = btn.closest('.post-card');
      const postId = btn.dataset.saveEdit;
      const area = card.querySelector('[data-editor-area]');
      const content = area.innerHTML.trim();

      if (content.length < 2) {
        if (window.toast) window.toast('Мінімум 2 символи', 'error');
        return;
      }

      const form = document.createElement('form');
      form.method = 'POST';
      form.innerHTML = `
        <input type="hidden" name="csrf" value="${window.CSRF_TOKEN}">
        <input type="hidden" name="action" value="edit-post">
        <input type="hidden" name="post_id" value="${postId}">
        <textarea name="content">${escapeHtml(content)}</textarea>
      `;
      document.body.appendChild(form);
      form.submit();
    });
  });

  function escapeHtml(s){
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /* ═══════════════════════════════════════════════════════════
     ІСТОРІЯ РЕДАГУВАНЬ
     ═══════════════════════════════════════════════════════════ */
  const modal = document.getElementById('historyModal');
  const body = document.getElementById('historyBody');

  $$('[data-history]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const postId = btn.dataset.history;
      const canRollback = btn.dataset.canRollback === '1';

      body.innerHTML = '<div class="history-empty">Завантаження...</div>';
      modal.classList.add('show');

      try {
        const res = await fetch(window.SITE_URL + '/api/history.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ post_id: parseInt(postId), csrf: window.CSRF_TOKEN })
        });
        const r = await res.json();

        if (!r.ok || !r.items || !r.items.length) {
          body.innerHTML = '<div class="history-empty">Ще немає редагувань</div>';
          return;
        }

        renderHistory(r.items, canRollback);
      } catch (e) {
        body.innerHTML = '<div class="history-empty">Помилка завантаження</div>';
      }
    });
  });

  function renderHistory(items, canRollback){
    body.innerHTML = '';

    items.forEach((item, idx) => {
      const block = document.createElement('div');
      block.className = 'history-item';
      if (item.is_rollback) block.classList.add('rollback');

      block.innerHTML = `
        <div class="history-meta">
          <div class="history-user">
            <img src="${escapeHtml(item.avatar_url)}" alt="" class="history-avatar">
            <div>
              <div class="history-username">${escapeHtml(item.username)}</div>
              <div class="history-time">${escapeHtml(item.edited_at_full)}</div>
            </div>
          </div>
          ${item.is_rollback ? '<span class="history-badge">Відкат</span>' : ''}
        </div>
        <div class="history-compare">
          <div class="history-col">
            <div class="history-col-head">
              <span class="history-badge-before">До</span>
            </div>
            <div class="history-content">${item.content_before}</div>
          </div>
          <div class="history-arrow">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
          </div>
          <div class="history-col">
            <div class="history-col-head">
              <span class="history-badge-after">Після</span>
            </div>
            <div class="history-content">${item.content_after}</div>
          </div>
        </div>
        ${canRollback ? `
          <div class="history-actions">
            <button type="button" class="btn btn-danger btn-sm" data-rollback="${item.id}">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>
              Відкатити до цієї версії
            </button>
          </div>
        ` : ''}
      `;
      body.appendChild(block);
    });

    // Обробники відкату
    body.querySelectorAll('[data-rollback]').forEach(btn => {
      btn.addEventListener('click', () => {
        const hid = btn.dataset.rollback;
        if (confirm('Відкатити пост до цієї версії?')) {
          const form = document.createElement('form');
          form.method = 'POST';
          form.innerHTML = `
            <input type="hidden" name="csrf" value="${window.CSRF_TOKEN}">
            <input type="hidden" name="action" value="rollback">
            <input type="hidden" name="history_id" value="${hid}">
          `;
          document.body.appendChild(form);
          form.submit();
        }
      });
    });
  }

  /* Закриття модалки */
  document.querySelectorAll('[data-close-history]').forEach(el => {
    el.addEventListener('click', () => modal.classList.remove('show'));
  });
  modal.addEventListener('click', e => {
    if (e.target === modal) modal.classList.remove('show');
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') modal.classList.remove('show');
  });
})();