<?php
require_once __DIR__ . '/../functions.php';
if (!canAccessAdmin()) redirect(SITE_URL);

/* ═══════════ ЗАГАЛЬНА СТАТИСТИКА ═══════════ */
$stats = $pdo->query("
  SELECT
    (SELECT COUNT(*) FROM users WHERE is_banned=0) AS users,
    (SELECT COUNT(*) FROM users WHERE is_banned=1) AS banned,
    (SELECT COUNT(*) FROM users WHERE last_seen > DATE_SUB(NOW(), INTERVAL 15 MINUTE)) AS online,
    (SELECT COUNT(*) FROM users WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)) AS new_users,
    (SELECT COUNT(*) FROM topics WHERE is_deleted=0) AS topics,
    (SELECT COUNT(*) FROM topics WHERE is_deleted=0 AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)) AS today_topics,
    (SELECT COUNT(*) FROM posts WHERE is_deleted=0) AS posts,
    (SELECT COUNT(*) FROM posts WHERE is_deleted=0 AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)) AS today_posts,
    (SELECT COUNT(*) FROM likes) AS likes,
    (SELECT COUNT(*) FROM categories WHERE is_hidden=0) AS categories
")->fetch();

/* ═══════════ АКТИВНІСТЬ 7 ДНІВ ═══════════ */
$activity = [];
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-$i days"));
    $stmt = $pdo->prepare("
      SELECT
        (SELECT COUNT(*) FROM topics WHERE DATE(created_at)=?) AS t,
        (SELECT COUNT(*) FROM posts  WHERE DATE(created_at)=?) AS p
    ");
    $stmt->execute([$day, $day]);
    $row = $stmt->fetch();
    $activity[] = [
        'label'  => date('d.m', strtotime($day)),
        'topics' => (int)$row['t'],
        'posts'  => (int)$row['p'],
        'total'  => (int)$row['t'] + (int)$row['p'],
    ];
}
$activityMax = 1;
foreach ($activity as $a) {
    if ($a['total'] > $activityMax) $activityMax = $a['total'];
}
$weekTotal = 0;
foreach ($activity as $a) $weekTotal += $a['total'];

/* ═══════════ ТОП АВТОРІВ ═══════════ */
$topAuthors = $pdo->query("
  SELECT u.id, u.username, u.avatar, u.role,
    (SELECT COUNT(*) FROM posts WHERE user_id=u.id AND is_deleted=0) AS posts_count,
    (SELECT COUNT(*) FROM topics WHERE user_id=u.id AND is_deleted=0) AS topics_count
  FROM users u WHERE u.is_banned=0
  ORDER BY (SELECT COUNT(*) FROM posts WHERE user_id=u.id AND is_deleted=0) DESC
  LIMIT 5
")->fetchAll();

/* ═══════════ ОСТАННІ ТЕМИ ═══════════ */
$recentTopics = $pdo->query("
  SELECT t.id, t.title, t.created_at, u.username,
         c.name AS cat_name, c.icon AS cat_icon, c.color AS cat_color
  FROM topics t
  JOIN users u ON t.user_id=u.id
  JOIN categories c ON t.category_id=c.id
  WHERE t.is_deleted=0
  ORDER BY t.created_at DESC
  LIMIT 5
")->fetchAll();

/* ═══════════ ОСТАННІ КОРИСТУВАЧІ ═══════════ */
$recentUsers = $pdo->query("
  SELECT id, username, avatar, role, created_at
  FROM users
  ORDER BY created_at DESC
  LIMIT 5
")->fetchAll();

/* ═══════════ СИСТЕМА ═══════════ */
$phpVersion = PHP_VERSION;
$mysqlVersion = '—';
try {
    $mysqlVersion = $pdo->query("SELECT VERSION()")->fetchColumn();
} catch (Exception $e) {
    $mysqlVersion = '—';
}

$pageTitle = 'Адмінка';
require __DIR__ . '/../header.php';
?>

<div class="breadcrumbs">
  <a href="<?= SITE_URL ?>"><?= icon('home', 12) ?> Головна</a>
  <span class="sep">/</span>
  <span class="current">Адмін-панель</span>
</div>

<div class="section-head">
  <h1 class="section-title"><?= icon('chart', 18) ?> Дашборд</h1>
  <span class="muted small">
    <?= icon('clock', 12) ?> Оновлено <?= date('d.m.Y H:i') ?>
  </span>
</div>

<div class="admin-nav">
  <a href="<?= SITE_URL ?>/admin/index.php" class="active"><?= icon('chart', 14) ?> Дашборд</a>
  <a href="<?= SITE_URL ?>/admin/users.php"><?= icon('users', 14) ?> Користувачі</a>
  <a href="<?= SITE_URL ?>/admin/categories.php"><?= icon('folder', 14) ?> Категорії</a>
  <a href="<?= SITE_URL ?>/admin/subforums.php"><?= icon('grid', 14) ?> Підфоруми</a>
  <a href="<?= SITE_URL ?>/admin/topics.php"><?= icon('file-text', 14) ?> Теми</a>
  <a href="<?= SITE_URL ?>/admin/roles.php"><?= icon('shield', 14) ?> Ролі</a>
  <a href="<?= SITE_URL ?>/admin/settings.php"><?= icon('settings', 14) ?> Налаштування</a>
</div>

<!-- ═══════════ БЛОК 1: КЛЮЧОВІ КАРТКИ ═══════════ -->
<div class="dash-grid">
  <div class="dash-card reveal">
    <div class="dash-card-top">
      <div class="dash-ico users"><?= icon('users', 18) ?></div>
      <div class="dash-trend <?= $stats['new_users'] > 0 ? 'up' : '' ?>">
        <?= icon('trend', 11) ?> +<?= (int)$stats['new_users'] ?> за тиждень
      </div>
    </div>
    <div class="dash-num" data-count="<?= (int)$stats['users'] ?>">0</div>
    <div class="dash-lbl">Користувачів</div>
    <div class="dash-sub">
      <span><?= icon('lock', 11) ?> <?= (int)$stats['banned'] ?> забанено</span>
    </div>
  </div>

  <div class="dash-card reveal">
    <div class="dash-card-top">
      <div class="dash-ico topics"><?= icon('file-text', 18) ?></div>
      <div class="dash-trend <?= $stats['today_topics'] > 0 ? 'up' : '' ?>">
        <?= icon('trend', 11) ?> +<?= (int)$stats['today_topics'] ?> сьогодні
      </div>
    </div>
    <div class="dash-num" data-count="<?= (int)$stats['topics'] ?>">0</div>
    <div class="dash-lbl">Тем</div>
    <div class="dash-sub">
      <span><?= icon('folder', 11) ?> <?= (int)$stats['categories'] ?> категорій</span>
    </div>
  </div>

  <div class="dash-card reveal">
    <div class="dash-card-top">
      <div class="dash-ico posts"><?= icon('message', 18) ?></div>
      <div class="dash-trend <?= $stats['today_posts'] > 0 ? 'up' : '' ?>">
        <?= icon('trend', 11) ?> +<?= (int)$stats['today_posts'] ?> сьогодні
      </div>
    </div>
    <div class="dash-num" data-count="<?= (int)$stats['posts'] ?>">0</div>
    <div class="dash-lbl">Повідомлень</div>
    <div class="dash-sub">
      <span><?= icon('heart', 11) ?> <?= (int)$stats['likes'] ?> лайків</span>
    </div>
  </div>

  <div class="dash-card reveal online-card">
    <div class="dash-card-top">
      <div class="dash-ico online"><span class="pulse-dot"></span></div>
      <div class="dash-trend online">
        <?= icon('eye', 11) ?> зараз на сайті
      </div>
    </div>
    <div class="dash-num" data-count="<?= (int)$stats['online'] ?>">0</div>
    <div class="dash-lbl">Онлайн</div>
    <div class="dash-sub">
      <span><?= icon('zap', 11) ?> активні за 15 хв</span>
    </div>
  </div>
</div>

<!-- ═══════════ БЛОК 2: ГРАФІК + ТОП АВТОРІВ ═══════════ -->
<div class="dash-row">

  <div class="dash-panel reveal">
    <div class="dash-panel-head">
      <div>
        <h3><?= icon('chart', 15) ?> Активність за 7 днів</h3>
        <p class="dash-panel-sub">Всього: <b><?= $weekTotal ?></b> дій</p>
      </div>
      <div class="dash-legend">
        <span><i class="dot-topics"></i> Теми</span>
        <span><i class="dot-posts"></i> Пости</span>
      </div>
    </div>

    <div class="dash-chart">
      <?php foreach ($activity as $i => $a):
        $h = $a['total'] > 0 ? max(6, round($a['total'] / $activityMax * 100)) : 3;
        $topicsH = $a['total'] > 0 ? round($a['topics'] / $a['total'] * 100) : 0;
      ?>
        <div class="dash-chart-col" style="animation-delay: <?= $i * 0.05 ?>s">
          <div class="dash-chart-bar" style="height:<?= $h ?>%"
               title="<?= e($a['label']) ?>: тем <?= $a['topics'] ?>, постів <?= $a['posts'] ?>">
            <div class="dash-chart-topics" style="height:<?= $topicsH ?>%"></div>
          </div>
          <div class="dash-chart-label"><?= e($a['label']) ?></div>
          <div class="dash-chart-value"><?= $a['total'] ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="dash-panel reveal">
    <div class="dash-panel-head">
      <h3><?= icon('award', 15) ?> Найактивніші</h3>
    </div>

    <?php if (!$topAuthors): ?>
      <div class="dash-empty">Ще немає активних користувачів</div>
    <?php else: ?>
      <div class="dash-authors">
        <?php foreach ($topAuthors as $i => $a):
          $rank = $i + 1;
          $rankClass = $rank <= 3 ? 'top-' . $rank : '';
        ?>
          <a href="<?= SITE_URL ?>/profile.php?id=<?= $a['id'] ?>" class="dash-author">
            <span class="dash-rank <?= $rankClass ?>"><?= $rank ?></span>
            <img src="<?= avatarUrl($a) ?>" class="avatar-xs" alt="">
            <div class="dash-author-info">
              <div class="dash-author-name">
                <?= e($a['username']) ?>
                <?php if ($a['role']==='admin'): ?><span class="badge role admin">ADMIN</span><?php endif; ?>
                <?php if ($a['role']==='moderator'): ?><span class="badge role mod">MOD</span><?php endif; ?>
              </div>
              <div class="dash-author-meta">
                <span><?= icon('message', 10) ?> <?= (int)$a['posts_count'] ?></span>
                <span><?= icon('file-text', 10) ?> <?= (int)$a['topics_count'] ?></span>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

</div>

<!-- ═══════════ БЛОК 3: ОСТАННІ ТЕМИ + НОВІ ЮЗЕРИ ═══════════ -->
<div class="dash-row">

  <div class="dash-panel reveal">
    <div class="dash-panel-head">
      <h3><?= icon('trend', 15) ?> Останні теми</h3>
      <a href="<?= SITE_URL ?>/admin/topics.php" class="dash-panel-link">
        Всі теми <?= icon('arrow-right', 12) ?>
      </a>
    </div>

    <?php if (!$recentTopics): ?>
      <div class="dash-empty">Ще немає тем</div>
    <?php else: ?>
      <div class="dash-recent">
        <?php foreach ($recentTopics as $t): ?>
          <a href="<?= SITE_URL ?>/topic.php?id=<?= $t['id'] ?>" class="dash-recent-item">
            <span class="dash-recent-ico" style="--tint: <?= e($t['cat_color']) ?>">
              <?= icon($t['cat_icon'] ?: 'hash', 15) ?>
            </span>
            <div class="dash-recent-body">
              <div class="dash-recent-title"><?= e($t['title']) ?></div>
              <div class="dash-recent-meta">
                <span><?= icon('user', 10) ?> <?= e($t['username']) ?></span>
                <span class="dot">·</span>
                <span><?= e($t['cat_name']) ?></span>
                <span class="dot">·</span>
                <span><?= timeAgo($t['created_at']) ?></span>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="dash-panel reveal">
    <div class="dash-panel-head">
      <h3><?= icon('sparkle', 15) ?> Нові користувачі</h3>
      <a href="<?= SITE_URL ?>/admin/users.php" class="dash-panel-link">
        Всі <?= icon('arrow-right', 12) ?>
      </a>
    </div>

    <?php if (!$recentUsers): ?>
      <div class="dash-empty">Ще немає користувачів</div>
    <?php else: ?>
      <div class="dash-users">
        <?php foreach ($recentUsers as $u): ?>
          <a href="<?= SITE_URL ?>/profile.php?id=<?= $u['id'] ?>" class="dash-user">
            <img src="<?= avatarUrl($u) ?>" alt="">
            <div class="dash-user-body">
              <div class="dash-user-name">
                <?= e($u['username']) ?>
                <?php if ($u['role']==='admin'): ?><span class="badge role admin">ADMIN</span><?php endif; ?>
                <?php if ($u['role']==='moderator'): ?><span class="badge role mod">MOD</span><?php endif; ?>
              </div>
              <div class="dash-user-meta">
                <?= icon('clock', 10) ?> <?= timeAgo($u['created_at']) ?>
              </div>
            </div>
            <span class="dash-user-arrow"><?= icon('arrow-right', 13) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

</div>

<!-- ═══════════ БЛОК 4: ШВИДКІ ДІЇ + СИСТЕМА ═══════════ -->
<div class="dash-row">

  <div class="dash-panel reveal">
    <div class="dash-panel-head">
      <h3><?= icon('zap', 15) ?> Швидкі дії</h3>
    </div>

    <div class="dash-actions">
      <a href="<?= SITE_URL ?>/admin/users.php" class="dash-action">
        <div class="dash-action-ico users"><?= icon('users', 18) ?></div>
        <div class="dash-action-body">
          <div class="dash-action-title">Користувачі</div>
          <div class="dash-action-desc">Управління акаунтами</div>
        </div>
        <?= icon('arrow-right', 14) ?>
      </a>

      <a href="<?= SITE_URL ?>/admin/categories.php" class="dash-action">
        <div class="dash-action-ico topics"><?= icon('folder', 18) ?></div>
        <div class="dash-action-body">
          <div class="dash-action-title">Категорії</div>
          <div class="dash-action-desc">Створення та редагування</div>
        </div>
        <?= icon('arrow-right', 14) ?>
      </a>

      <a href="<?= SITE_URL ?>/admin/topics.php" class="dash-action">
        <div class="dash-action-ico posts"><?= icon('file-text', 18) ?></div>
        <div class="dash-action-body">
          <div class="dash-action-title">Теми</div>
          <div class="dash-action-desc">Модерація контенту</div>
        </div>
        <?= icon('arrow-right', 14) ?>
      </a>

      <a href="<?= SITE_URL ?>/admin/roles.php" class="dash-action">
        <div class="dash-action-ico online"><?= icon('shield', 18) ?></div>
        <div class="dash-action-body">
          <div class="dash-action-title">Ролі</div>
          <div class="dash-action-desc">Доступи та права</div>
        </div>
        <?= icon('arrow-right', 14) ?>
      </a>
    </div>
  </div>

  <div class="dash-panel reveal">
    <div class="dash-panel-head">
      <h3><?= icon('shield', 15) ?> Система</h3>
    </div>

    <div class="dash-system">
      <div class="dash-sys-item">
        <div class="dash-sys-lbl"><?= icon('zap', 12) ?> PHP</div>
        <div class="dash-sys-value"><?= e($phpVersion) ?></div>
      </div>
      <div class="dash-sys-item">
        <div class="dash-sys-lbl"><?= icon('grid', 12) ?> MySQL</div>
        <div class="dash-sys-value"><?= e($mysqlVersion) ?></div>
      </div>
      <div class="dash-sys-item">
        <div class="dash-sys-lbl"><?= icon('clock', 12) ?> Час</div>
        <div class="dash-sys-value"><?= date('H:i') ?></div>
      </div>
      <div class="dash-sys-item">
        <div class="dash-sys-lbl"><?= icon('user', 12) ?> Роль</div>
        <div class="dash-sys-value"><?= e(currentUser()['role'] ?? '—') ?></div>
      </div>
    </div>
  </div>

</div>

<?php require __DIR__ . '/../footer.php'; ?>