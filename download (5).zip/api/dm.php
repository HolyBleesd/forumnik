<?php
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Не авторизовано']);
    exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
if (!checkCsrf($in['csrf'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF']);
    exit;
}

$action = $in['action'] ?? '';
$uid = (int)$_SESSION['user_id'];

try {
    switch ($action) {

        case 'open':
            $otherId = (int)($in['user_id'] ?? 0);
            if (!$otherId) throw new Exception('Невірний ID');
            $did = getOrCreateDialog($uid, $otherId);

            $stmt = $pdo->prepare("SELECT username, avatar, role FROM users WHERE id = ?");
            $stmt->execute([$otherId]);
            $other = $stmt->fetch();

            echo json_encode([
                'ok' => true,
                'dialog_id' => $did,
                'other' => [
                    'id' => $otherId,
                    'username' => $other['username'],
                    'avatar' => avatarUrl(['username' => $other['username'], 'avatar' => $other['avatar']]),
                    'role' => $other['role'],
                ]
            ]);
            break;

        case 'messages':
            $did = (int)($in['dialog_id'] ?? 0);
            $since = (int)($in['since'] ?? 0);
            if (!$did) throw new Exception('Невірний ID');

            // Перевірка доступу
            $stmt = $pdo->prepare("SELECT * FROM dm_dialogs WHERE id = ?");
            $stmt->execute([$did]);
            $d = $stmt->fetch();
            if (!$d || ((int)$d['user1_id'] !== $uid && (int)$d['user2_id'] !== $uid)) {
                throw new Exception('Немає доступу');
            }

            // Позначити прочитаним
            $pdo->prepare("UPDATE dm_messages SET is_read = 1 WHERE dialog_id = ? AND sender_id != ?")
                ->execute([$did, $uid]);

            $messages = getDialogMessages($did, $since);
            $out = [];
            foreach ($messages as $m) {
                $out[] = [
                    'id' => (int)$m['id'],
                    'sender_id' => (int)$m['sender_id'],
                    'username' => $m['username'],
                    'avatar' => avatarUrl(['username' => $m['username'], 'avatar' => $m['avatar']]),
                    'message' => $m['message'],
                    'is_mine' => (int)$m['sender_id'] === $uid,
                    'created_at' => timeAgo($m['created_at']),
                    'time' => date('H:i', strtotime($m['created_at'])),
                ];
            }
            echo json_encode(['ok' => true, 'messages' => $out]);
            break;

        case 'send':
            $did = (int)($in['dialog_id'] ?? 0);
            $msg = trim($in['message'] ?? '');
            if (!$did || !$msg) throw new Exception('Порожнє');

            $stmt = $pdo->prepare("SELECT * FROM dm_dialogs WHERE id = ?");
            $stmt->execute([$did]);
            $d = $stmt->fetch();
            if (!$d || ((int)$d['user1_id'] !== $uid && (int)$d['user2_id'] !== $uid)) {
                throw new Exception('Немає доступу');
            }

            $mid = sendDm($did, $uid, $msg);
            echo json_encode(['ok' => true, 'message_id' => $mid]);
            break;

        case 'dialogs':
            $list = getDialogsList($uid);
            $out = [];
            foreach ($list as $d) {
                $out[] = [
                    'id' => (int)$d['id'],
                    'other_id' => (int)$d['other_id'],
                    'other_name' => $d['other_name'],
                    'other_avatar' => avatarUrl(['username' => $d['other_name'], 'avatar' => $d['other_avatar']]),
                    'last_message' => mb_substr(strip_tags($d['last_message'] ?? ''), 0, 60),
                    'unread' => (int)$d['unread'],
                    'time' => timeAgo($d['last_message_at']),
                ];
            }
            echo json_encode(['ok' => true, 'dialogs' => $out]);
            break;

        default:
            throw new Exception('Невідома дія');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}