<?php
require_once __DIR__ . '/../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Не авторизовано']);
    exit;
}

if (!canViewHistory()) {
    http_response_code(403);
    echo json_encode(['error' => 'Немає доступу']);
    exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
if (!checkCsrf($in['csrf'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF']);
    exit;
}

$postId = (int)($in['post_id'] ?? 0);
if (!$postId) {
    echo json_encode(['error' => 'no post_id']);
    exit;
}

$history = getPostHistory($postId);

$items = [];
foreach ($history as $h) {
    $items[] = [
        'id'             => (int)$h['id'],
        'username'       => $h['username'],
        'avatar_url'     => avatarUrl(['username' => $h['username'], 'avatar' => $h['avatar']]),
        'edited_at'      => $h['edited_at'],
        'edited_at_full' => realDateTime($h['edited_at']),
        'content_before' => $h['content_before'],
        'content_after'  => $h['content_after'],
        'is_rollback'    => (int)$h['is_rollback'] === 1,
    ];
}

echo json_encode(['ok' => true, 'items' => $items]);