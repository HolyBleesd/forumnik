'use strict';

/* ═══════════════════════════════════════════════════════════
   ГЛОБАЛЬНІ 3D-АНІМАЦІЇ
   ═══════════════════════════════════════════════════════════ */

(function(){
  /* ═══════════════════════════════════════════════════════════
     SCROLL PROGRESS BAR
     ═══════════════════════════════════════════════════════════ */
  function initScrollProgress(){
    const bar = document.querySelector('.scroll-progress-fill');
    if (!bar) return;

    let ticking = false;
    const update = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      const p = h > 0 ? (window.scrollY / h) * 100 : 0;
      bar.style.width = p + '%';
      ticking = false;
    };

    window.addEventListener('scroll', () => {
      if (!ticking) {
        requestAnimationFrame(update);
        ticking = true;
      }
    }, { passive: true });
    update();
  }

  /* ═══════════════════════════════════════════════════════════
     ПЛАВНІ ЯКОРІ
     ═══════════════════════════════════════════════════════════ */
  function initSmoothAnchors(){
    document.querySelectorAll('a[href^="#"], [data-scroll-to]').forEach(el => {
      el.addEventListener('click', e => {
        const href = el.getAttribute('href') || el.dataset.scrollTo;
        if (!href || href === '#') return;

        const id = href.startsWith('#') ? href.slice(1) : href;
        const target = document.getElementById(id);
        if (!target) return;

        e.preventDefault();

        const top = target.getBoundingClientRect().top + window.scrollY - 80;
        window.scrollTo({ top, behavior: 'smooth' });
      });
    });
  }

  /* ═══════════════════════════════════════════════════════════
     ВІДНОВЛЕННЯ ПОЗИЦІЇ СКРОЛУ
     ═══════════════════════════════════════════════════════════ */
  function initScrollRestore(){
    const STORAGE_KEY = 'scrollPos:' + location.pathname;

    // Керуємо відновленням вручну
    if ('scrollRestoration' in history) {
      history.scrollRestoration = 'manual';
    }

    // Відновлення
    window.addEventListener('load', () => {
      const saved = sessionStorage.getItem(STORAGE_KEY);
      if (saved) {
        const y = parseInt(saved, 10);
        if (!isNaN(y) && y > 0) {
          setTimeout(() => {
            window.scrollTo({ top: y, behavior: 'auto' });
          }, 30);
        }
      }
      sessionStorage.removeItem(STORAGE_KEY);
    });

    // Зберігаємо перед переходом
    window.addEventListener('beforeunload', () => {
      sessionStorage.setItem(STORAGE_KEY, window.scrollY);
    });
  }

  /* ═══════════════════════════════════════════════════════════
     REVEAL 3D
     ═══════════════════════════════════════════════════════════ */
  function initReveal3D(){
    if (!('IntersectionObserver' in window)) {
      document.querySelectorAll('.reveal-3d, .slide-left, .slide-right, .zoom-in')
        .forEach(el => el.classList.add('is-visible'));
      return;
    }

    const io = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (en.isIntersecting) {
          en.target.classList.add('is-visible');
          io.unobserve(en.target);
        }
      });
    }, {
      threshold: 0.08,
      rootMargin: '0px 0px -60px 0px'
    });

    document.querySelectorAll(
      '.reveal-3d, .slide-left, .slide-right, .zoom-in'
    ).forEach(el => io.observe(el));
  }

  function autoTagSections(){
    document.querySelectorAll(
      '.section, .topic-main, .profile-hero, .profile-section, ' +
      '.editor-block, .settings-card, .dash-card, .dash-panel, ' +
      '.cat-tree-item, .user-admin-card, .role-card, .pcard'
    ).forEach(el => {
      if (!el.classList.contains('reveal-3d') && !el.classList.contains('reveal')) {
        el.classList.add('reveal-3d');
      }
    });
  }

  function autoStagger(){
    document.querySelectorAll(
      '.topics-list, .posts-list, .cat-list, .notifications, .side-authors, .side-latest'
    ).forEach(list => {
      list.classList.add('stagger-reveal');
    });
  }

  /* ═══════════════════════════════════════════════════════════
     3D TILT
     ═══════════════════════════════════════════════════════════ */
  function initTilt(){
    document.querySelectorAll('[data-tilt], .tilt-3d').forEach(card => {
      if (card.dataset.tiltInit) return;
      card.dataset.tiltInit = '1';

      let isHovering = false;
      card.addEventListener('mouseenter', () => { isHovering = true; });
      card.addEventListener('mouseleave', () => {
        isHovering = false;
        card.style.transform = '';
      });
      card.addEventListener('mousemove', e => {
        if (!isHovering) return;
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        card.style.transform =
          `perspective(1000px) rotateX(${y * -8}deg) rotateY(${x * 8}deg) translateZ(6px)`;
      });
    });
  }

  /* ═══════════════════════════════════════════════════════════
     MAGNETIC BUTTONS
     ═══════════════════════════════════════════════════════════ */
  function initMagnetic(){
    document.querySelectorAll('.btn-primary, .lp-btn-primary, .um-btn-primary, [data-magnetic]').forEach(btn => {
      if (btn.dataset.magneticInit) return;
      btn.dataset.magneticInit = '1';
      btn.classList.add('magnetic');

      let rect = null;
      btn.addEventListener('mouseenter', () => {
        rect = btn.getBoundingClientRect();
      });
      btn.addEventListener('mousemove', e => {
        if (!rect) rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        btn.style.transform = `translate(${x * 0.12}px, ${y * 0.18}px)`;
      });
      btn.addEventListener('mouseleave', () => {
        btn.style.transform = '';
        rect = null;
      });
    });
  }

  /* ═══════════════════════════════════════════════════════════
     RIPPLE
     ═══════════════════════════════════════════════════════════ */
  function initRipple(){
    document.querySelectorAll('.btn, .lp-btn, .um-btn, .btn-action, .icon-btn').forEach(btn => {
      if (btn.dataset.rippleInit) return;
      btn.dataset.rippleInit = '1';
      btn.classList.add('ripple');

      btn.addEventListener('click', e => {
        const r = btn.getBoundingClientRect();
        const x = e.clientX - r.left;
        const y = e.clientY - r.top;
        const size = Math.max(r.width, r.height) * 2;

        const circle = document.createElement('span');
        circle.style.cssText = `
          position:absolute;
          left:${x}px;
          top:${y}px;
          width:0;
          height:0;
          border-radius:50%;
          background:rgba(255,255,255,.35);
          transform:translate(-50%,-50%);
          pointer-events:none;
          transition:width .5s ease, height .5s ease, opacity .5s ease;
          opacity:1;
        `;
        btn.appendChild(circle);

        requestAnimationFrame(() => {
          circle.style.width = size + 'px';
          circle.style.height = size + 'px';
          circle.style.opacity = '0';
        });

        setTimeout(() => circle.remove(), 600);
      });
    });
  }

  /* ═══════════════════════════════════════════════════════════
     SCROLL TO TOP
     ═══════════════════════════════════════════════════════════ */
  function initScrollTop(){
    if (document.querySelector('.scroll-top-btn')) return;

    const btn = document.createElement('button');
    btn.className = 'scroll-top-btn';
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
           fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="m18 15-6-6-6 6"/>
      </svg>
    `;
    btn.setAttribute('aria-label', 'Нагору');
    document.body.appendChild(btn);

    btn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    let ticking = false;
    const update = () => {
      btn.classList.toggle('show', window.scrollY > 500);
      ticking = false;
    };
    window.addEventListener('scroll', () => {
      if (!ticking) {
        requestAnimationFrame(update);
        ticking = true;
      }
    }, { passive: true });
  }

  /* ═══════════════════════════════════════════════════════════
     INIT
     ═══════════════════════════════════════════════════════════ */
  function initAll(){
    autoTagSections();
    autoStagger();
    initScrollProgress();
    initReveal3D();
    initTilt();
    initMagnetic();
    initRipple();
    initSmoothAnchors();
    initScrollRestore();
    initScrollTop();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

  window.initAnimations = initAll;
})();