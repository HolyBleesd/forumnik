'use strict';

/* ═══════════════════════════════════════════════════════════
   MAJESTIC-STYLE: МОДАЛЬНІ ВІКНА + TOAST
   ═══════════════════════════════════════════════════════════ */

(function() {
  // ─── Ініціалізація контейнерів ───
  function ensureContainers() {
    if (!document.getElementById('toastStack')) {
      const stack = document.createElement('div');
      stack.id = 'toastStack';
      stack.className = 'toast-stack';
      document.body.appendChild(stack);
    }
    if (!document.getElementById('modalRoot')) {
      const root = document.createElement('div');
      root.id = 'modalRoot';
      root.className = 'modal-root';
      document.body.appendChild(root);
    }
  }

  /* ═════════════════════════════════════════════════════════
     TOAST
     ═════════════════════════════════════════════════════════ */
  const ICONS = {
    success: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5L20 7"/></svg>',
    error:   '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    info:    '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v5h1"/></svg>',
    warning: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5M12 18h.01"/></svg>',
  };

  function showToast(msg, type = 'info', duration = 3000) {
    ensureContainers();
    const stack = document.getElementById('toastStack');

    const el = document.createElement('div');
    el.className = 'toast-item toast-' + type;
    el.innerHTML = `
      <span class="toast-ico">${ICONS[type] || ICONS.info}</span>
      <span class="toast-text">${escapeHtml(msg)}</span>
      <button class="toast-close" aria-label="Закрити">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
      </button>
      <div class="toast-progress"></div>
    `;

    stack.appendChild(el);

    void el.offsetWidth;
    el.classList.add('toast-show');

    const progress = el.querySelector('.toast-progress');
    progress.style.animationDuration = duration + 'ms';

    let timer = setTimeout(() => closeToast(el), duration);

    const close = () => {
      clearTimeout(timer);
      closeToast(el);
    };

    el.querySelector('.toast-close').addEventListener('click', close);
    el.addEventListener('mouseenter', () => {
      clearTimeout(timer);
      progress.style.animationPlayState = 'paused';
    });
    el.addEventListener('mouseleave', () => {
      const remaining = duration * 0.4;
      timer = setTimeout(() => closeToast(el), remaining);
      progress.style.animationPlayState = 'running';
    });
  }

  function closeToast(el) {
    if (!el || el.classList.contains('toast-hide')) return;
    el.classList.add('toast-hide');
    setTimeout(() => el.remove(), 300);
  }

  /* ═════════════════════════════════════════════════════════
     MODAL
     ═════════════════════════════════════════════════════════ */
  function showModal(opts) {
    ensureContainers();
    const root = document.getElementById('modalRoot');

    const o = Object.assign({
      title: 'Підтвердження',
      text: 'Ви впевнені?',
      icon: 'warning',
      confirmText: 'Підтвердити',
      cancelText: 'Скасувати',
      confirmStyle: 'primary',
      onConfirm: () => {},
      onCancel: () => {},
    }, opts);

    const MODAL_ICONS = {
      warning: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5M12 18h.01"/></svg>',
      danger:  '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/></svg>',
      question:'<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 1-1 1.7v.5"/><path d="M12 17h.01"/></svg>',
      success: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5L20 7"/></svg>',
    };

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-box modal-3d-enter" role="dialog" aria-modal="true">
        <div class="modal-ico modal-ico-${o.icon}">${MODAL_ICONS[o.icon] || MODAL_ICONS.warning}</div>
        <h3 class="modal-title">${escapeHtml(o.title)}</h3>
        <p class="modal-text">${escapeHtml(o.text)}</p>
        <div class="modal-actions">
          <button class="modal-btn modal-btn-ghost" data-act="cancel">${escapeHtml(o.cancelText)}</button>
          <button class="modal-btn modal-btn-${o.confirmStyle}" data-act="confirm">${escapeHtml(o.confirmText)}</button>
        </div>
      </div>
    `;

    root.appendChild(overlay);
    void overlay.offsetWidth;
    overlay.classList.add('modal-open');

    // 3D-анімація боксу
    const box = overlay.querySelector('.modal-box');
    if (box) {
      requestAnimationFrame(() => {
        box.classList.add('is-open');
      });
    }

    setTimeout(() => {
      const btn = overlay.querySelector('[data-act="confirm"]');
      if (btn) btn.focus();
    }, 200);

    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      overlay.classList.remove('modal-open');
      overlay.classList.add('modal-closing');
      if (box) box.classList.remove('is-open');
      setTimeout(() => overlay.remove(), 300);
      document.removeEventListener('keydown', onKey);
    };

    const onKey = (e) => {
      if (e.key === 'Escape') { close(); o.onCancel && o.onCancel(); }
      if (e.key === 'Enter')  { close(); o.onConfirm && o.onConfirm(); }
    };
    document.addEventListener('keydown', onKey);

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        close();
        o.onCancel && o.onCancel();
      }
    });

    overlay.querySelector('[data-act="cancel"]').addEventListener('click', () => {
      close();
      o.onCancel && o.onCancel();
    });
    overlay.querySelector('[data-act="confirm"]').addEventListener('click', () => {
      close();
      o.onConfirm && o.onConfirm();
    });
  }

  /* ═════════════════════════════════════════════════════════
     УТИЛІТИ
     ═════════════════════════════════════════════════════════ */
  function escapeHtml(s) {
    return String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Експорт глобально
  window.toast   = showToast;
  window.modal   = showModal;
  window.confirmModal = (text, onConfirm, opts = {}) => {
    showModal(Object.assign({
      text: text,
      onConfirm: onConfirm,
    }, opts));
  };
})();