<?php
require_once __DIR__ . '/../functions.php';
if (!canAccessAdmin()) redirect(SITE_URL);

/* ═══════════ ОБРОБКА ═══════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && checkCsrf($_POST['csrf'] ?? '')) {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'create_cat') {
            $name = trim($_POST['name'] ?? '');
            if ($name === '') throw new Exception('Введіть назву');

            $pdo->prepare("INSERT INTO categories (name,description,icon,color,sort_order) VALUES (?,?,?,?,?)")
                ->execute([
                    $name,
                    trim($_POST['description'] ?? ''),
                    trim($_POST['icon']) ?: 'message',
                    $_POST['color'] ?? '#5b6ee1',
                    (int)($_POST['sort_order'] ?? 0)
                ]);
            $catId = (int)$pdo->lastInsertId();

            if (!empty($_POST['role_perms']) && is_array($_POST['role_perms'])) {
                $ins = $pdo->prepare("INSERT INTO category_permissions (category_id, role_id, permission) VALUES (?,?,?)");
                foreach ($_POST['role_perms'] as $roleId => $perms) {
                    if (!is_array($perms)) continue;
                    foreach ($perms as $p) $ins->execute([$catId, (int)$roleId, $p]);
                }
            }
            flash('Категорію створено', 'success');

        } elseif ($action === 'update_cat') {
            $id = (int)$_POST['id'];
            if (!$id) throw new Exception('Невірний ID');

            $pdo->prepare("UPDATE categories SET name=?,description=?,icon=?,color=?,sort_order=?,is_hidden=? WHERE id=?")
                ->execute([
                    trim($_POST['name']),
                    trim($_POST['description'] ?? ''),
                    trim($_POST['icon']) ?: 'message',
                    $_POST['color'] ?? '#5b6ee1',
                    (int)($_POST['sort_order'] ?? 0),
                    isset($_POST['is_hidden']) ? 1 : 0,
                    $id
                ]);

            $pdo->prepare("DELETE FROM category_permissions WHERE category_id=? AND subcategory_id IS NULL")->execute([$id]);

            if (!empty($_POST['role_perms']) && is_array($_POST['role_perms'])) {
                $ins = $pdo->prepare("INSERT INTO category_permissions (category_id, role_id, permission) VALUES (?,?,?)");
                foreach ($_POST['role_perms'] as $roleId => $perms) {
                    if (!is_array($perms)) continue;
                    foreach ($perms as $p) $ins->execute([$id, (int)$roleId, $p]);
                }
            }
            flash('Категорію оновлено', 'success');

        } elseif ($action === 'delete_cat') {
            $id = (int)$_POST['id'];
            $pdo->prepare("DELETE FROM categories WHERE id=?")->execute([$id]);
            flash('Категорію видалено', 'success');
        }
    } catch (Exception $e) {
        flash($e->getMessage(), 'error');
    }

    redirect(SITE_URL . '/admin/categories.php');
}

/* ═══════════ ДАНІ ═══════════ */
$cats = $pdo->query("
    SELECT c.*,
      (SELECT COUNT(*) FROM topics WHERE category_id=c.id AND is_deleted=0) AS topic_count,
      (SELECT COUNT(*) FROM subforums WHERE category_id=c.id) AS sub_count
    FROM categories c ORDER BY sort_order, id
")->fetchAll();

$roles = $pdo->query("SELECT * FROM roles ORDER BY sort_order")->fetchAll();

$iconList = [
    'message','monitor','gamepad','music','dice','bulb','flame','star','heart',
    'palette','camera','film','book','award','globe','bug','folder','hash','grid',
    'user','users','shield','bell','file-text','pin','eye','zap','sparkle','settings','chart','trend'
];

$topicPerms = [
    'topic.view'        => 'Переглядати теми',
    'topic.create'      => 'Створювати теми',
    'topic.reply'       => 'Відповідати в темах',
    'topic.edit_own'    => 'Редагувати свої теми',
    'topic.edit_any'    => 'Редагувати чужі теми',
    'topic.delete_own'  => 'Видаляти свої теми',
    'topic.delete_any'  => 'Видаляти чужі теми',
    'topic.close'       => 'Відкривати/закривати теми',
    'topic.pin'         => 'Прикріпляти/відкріпляти теми',
    'topic.move'        => 'Переміщувати теми',
];

$pageTitle = 'Категорії';
require __DIR__ . '/../header.php';
?>

<div class="breadcrumbs">
  <a href="<?= SITE_URL ?>"><?= icon('home', 12) ?> Головна</a>
  <span class="sep">/</span>
  <a href="<?= SITE_URL ?>/admin/index.php">Адмінка</a>
  <span class="sep">/</span>
  <span class="current">Категорії</span>
</div>

<div class="section-head">
  <h1 class="section-title"><?= icon('folder', 18) ?> Категорії</h1>
  <button class="btn btn-primary btn-sm" id="openCreateCat">
    <?= icon('plus', 15) ?> Нова категорія
  </button>
</div>

<div class="admin-nav">
  <a href="<?= SITE_URL ?>/admin/index.php"><?= icon('chart', 14) ?> Дашборд</a>
  <a href="<?= SITE_URL ?>/admin/users.php"><?= icon('users', 14) ?> Користувачі</a>
  <a href="<?= SITE_URL ?>/admin/categories.php" class="active"><?= icon('folder', 14) ?> Категорії</a>
  <a href="<?= SITE_URL ?>/admin/subforums.php"><?= icon('grid', 14) ?> Підфоруми</a>
  <a href="<?= SITE_URL ?>/admin/topics.php"><?= icon('file-text', 14) ?> Теми</a>
  <a href="<?= SITE_URL ?>/admin/roles.php"><?= icon('shield', 14) ?> Ролі</a>
  <a href="<?= SITE_URL ?>/admin/settings.php"><?= icon('settings', 14) ?> Налаштування</a>
</div>

<div class="cat-tree">
  <?php foreach ($cats as $c): ?>
    <div class="cat-tree-item" style="--tint: <?= e($c['color']) ?>">
      <div class="cat-tree-head">
        <div class="cat-tree-ico"><?= icon($c['icon'] ?: 'hash', 20) ?></div>
        <div class="cat-tree-info">
          <div class="cat-tree-name"><?= e($c['name']) ?></div>
          <div class="cat-tree-meta">
            <span><?= icon('file-text', 11) ?> <?= (int)$c['topic_count'] ?> тем</span>
            <span><?= icon('grid', 11) ?> <?= (int)$c['sub_count'] ?> підфорумів</span>
          </div>
        </div>
        <div class="cat-tree-actions">
          <button type="button" class="cat-act-btn" data-edit-cat="<?= $c['id'] ?>"><?= icon('edit', 13) ?> Редагувати</button>
          <a href="<?= SITE_URL ?>/admin/subforums.php?cat=<?= $c['id'] ?>" class="cat-act-btn"><?= icon('grid', 13) ?> Підфоруми</a>
          <form method="post" class="cat-act-form" onsubmit="return confirm('Видалити категорію?')">
            <input type="hidden" name="csrf" value="<?= csrf() ?>">
            <input type="hidden" name="action" value="delete_cat">
            <input type="hidden" name="id" value="<?= $c['id'] ?>">
            <button type="submit" class="cat-act-btn danger"><?= icon('trash', 13) ?></button>
          </form>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- МОДАЛКА КАТЕГОРІЇ -->
<div class="role-modal" id="catModal">
  <div class="role-modal-box role-modal-box-lg">
    <div class="role-modal-head">
      <h3 id="catModalTitle"><?= icon('folder', 16) ?> Категорія</h3>
      <button type="button" class="role-modal-close" data-close-modal><?= icon('x', 16) ?></button>
    </div>

    <form method="post" class="role-modal-form" id="catForm">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="action" id="catAction" value="create_cat">
      <input type="hidden" name="id" id="catId">

      <div class="role-modal-row">
        <label>Назва<input type="text" name="name" id="catName" required></label>
        <label>Порядок<input type="number" name="sort_order" id="catSort" value="0"></label>
      </div>

      <label>Опис<input type="text" name="description" id="catDesc"></label>

      <label>Колір
        <div class="color-input-wrap">
          <input type="color" name="color" id="catColor" value="#5b6ee1" class="color-input">
          <span class="color-value">#5b6ee1</span>
        </div>
      </label>

      <div class="form-group">
        <span class="form-label">Іконка</span>
        <div class="icon-picker" data-picker="cat">
          <?php foreach ($iconList as $ic): ?>
            <label class="icon-picker-item">
              <input type="radio" name="icon" value="<?= $ic ?>">
              <span class="icon-picker-box"><?= icon($ic, 18) ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <label class="cat-checkbox"><input type="checkbox" name="is_hidden" id="catHidden"> Приховати категорію</label>

      <div class="perm-matrix">
        <div class="perm-matrix-head">
          <span class="form-label"><?= icon('shield', 13) ?> Доступи для ролей</span>
          <small class="muted">Порожньо = глобальні дозволи ролі</small>
        </div>

        <?php foreach ($roles as $r): ?>
          <div class="perm-role-block" style="--tint: <?= e($r['color']) ?>">
            <div class="perm-role-name"><?= icon('shield', 12) ?> <?= e($r['name']) ?></div>
            <div class="perm-role-items perm-role-items-grouped">
              <div class="perm-group-label">Перегляд і створення</div>
              <?php foreach (['topic.view','topic.create','topic.reply'] as $key): ?>
                <label class="perm-checkbox">
                  <input type="checkbox" name="role_perms[<?= $r['id'] ?>][]" value="<?= $key ?>">
                  <span><?= e($topicPerms[$key]) ?></span>
                </label>
              <?php endforeach; ?>
              <div class="perm-group-label">Редагування</div>
              <?php foreach (['topic.edit_own','topic.edit_any'] as $key): ?>
                <label class="perm-checkbox">
                  <input type="checkbox" name="role_perms[<?= $r['id'] ?>][]" value="<?= $key ?>">
                  <span><?= e($topicPerms[$key]) ?></span>
                </label>
              <?php endforeach; ?>
              <div class="perm-group-label">Видалення</div>
              <?php foreach (['topic.delete_own','topic.delete_any'] as $key): ?>
                <label class="perm-checkbox">
                  <input type="checkbox" name="role_perms[<?= $r['id'] ?>][]" value="<?= $key ?>">
                  <span><?= e($topicPerms[$key]) ?></span>
                </label>
              <?php endforeach; ?>
              <div class="perm-group-label">Модерація</div>
              <?php foreach (['topic.close','topic.pin','topic.move'] as $key): ?>
                <label class="perm-checkbox">
                  <input type="checkbox" name="role_perms[<?= $r['id'] ?>][]" value="<?= $key ?>">
                  <span><?= e($topicPerms[$key]) ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="role-modal-actions">
        <button type="button" class="btn btn-ghost" data-close-modal>Скасувати</button>
        <button type="submit" class="btn btn-primary"><?= icon('check', 15) ?> Зберегти</button>
      </div>
    </form>
  </div>
</div>

<script>
window.CATS_DATA = <?= json_encode(array_map(function($c) {
    $perms = [];
    foreach (getCategoryPermissions((int)$c['id']) as $p) {
        $perms[(int)$p['role_id']][] = $p['permission'];
    }
    return [
        'id' => (int)$c['id'],
        'name' => $c['name'],
        'description' => $c['description'],
        'icon' => $c['icon'],
        'color' => $c['color'],
        'sort_order' => (int)$c['sort_order'],
        'is_hidden' => (int)$c['is_hidden'],
        'permissions' => $perms,
    ];
}, $cats)) ?>;

(function(){
  const $ = id => document.getElementById(id);
  const modal = $('catModal');
  const form = $('catForm');

  function clearPerms() {
    form.querySelectorAll('.perm-checkbox input').forEach(cb => cb.checked = false);
  }
  function setPerms(permsMap) {
    clearPerms();
    Object.keys(permsMap || {}).forEach(roleId => {
      (permsMap[roleId] || []).forEach(perm => {
        const cb = form.querySelector(`input[name="role_perms[${roleId}][]"][value="${perm}"]`);
        if (cb) cb.checked = true;
      });
    });
  }

  $('openCreateCat').addEventListener('click', () => {
    $('catModalTitle').innerHTML = '📁 Нова категорія';
    $('catAction').value = 'create_cat';
    $('catId').value = '';
    form.reset();
    clearPerms();
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  });

  document.querySelectorAll('[data-edit-cat]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.editCat);
      const cat = (window.CATS_DATA || []).find(c => c.id === id);
      if (!cat) return;

      $('catModalTitle').innerHTML = '✏️ Редагувати категорію';
      $('catAction').value = 'update_cat';
      $('catId').value = cat.id;
      $('catName').value = cat.name;
      $('catDesc').value = cat.description || '';
      $('catColor').value = cat.color;
      $('catSort').value = cat.sort_order;
      $('catHidden').checked = cat.is_hidden === 1;

      form.querySelectorAll('input[name="icon"]').forEach(inp => {
        inp.checked = inp.value === cat.icon;
      });
      setPerms(cat.permissions);

      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  document.querySelectorAll('[data-close-modal]').forEach(el => {
    el.addEventListener('click', () => {
      el.closest('.role-modal').classList.remove('open');
      document.body.style.overflow = '';
    });
  });
  modal.addEventListener('click', e => {
    if (e.target === modal) {
      modal.classList.remove('open');
      document.body.style.overflow = '';
    }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      modal.classList.remove('open');
      document.body.style.overflow = '';
    }
  });

  document.querySelectorAll('.color-input').forEach(inp => {
    inp.addEventListener('input', e => {
      const v = e.target.parentElement.querySelector('.color-value');
      if (v) v.textContent = e.target.value;
    });
  });
})();
</script>

<?php require __DIR__ . '/../footer.php'; ?>