<?php
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Не авторизовано']);
    exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
if (!checkCsrf($in['csrf'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF']);
    exit;
}

$action = $in['action'] ?? '';

try {
    switch ($action) {

        /* ─── Видати покарання ─── */
        case 'issue':
            $userId = (int)($in['user_id'] ?? 0);
            $type   = $in['type'] ?? '';
            $reason = trim($in['reason'] ?? '');
            $duration = (int)($in['duration'] ?? 0); // у годинах, 0 = назавжди

            if (!$userId || !$type || mb_strlen($reason) < 3) {
                throw new Exception('Заповніть усі поля');
            }
            if (!in_array($type, ['warn','mute','ban'], true)) {
                throw new Exception('Невірний тип покарання');
            }
            if (!canPunish($type)) {
                throw new Exception('Немає прав');
            }
            if ($userId === (int)$_SESSION['user_id']) {
                throw new Exception('Не можна покарати себе');
            }

            $expiresAt = null;
            if ($duration > 0) {
                $expiresAt = date('Y-m-d H:i:s', time() + $duration * 3600);
            }

            $pid = issuePunishment($userId, $type, $reason, (int)$_SESSION['user_id'], $expiresAt);
            echo json_encode(['ok' => true, 'id' => $pid]);
            break;

        /* ─── Зняти покарання ─── */
        case 'revoke':
            $pid = (int)($in['punishment_id'] ?? 0);
            if (!$pid) throw new Exception('Невірний ID');

            $stmt = $pdo->prepare("SELECT * FROM user_punishments WHERE id = ?");
            $stmt->execute([$pid]);
            $p = $stmt->fetch();
            if (!$p) throw new Exception('Покарання не знайдено');
            if (!canPunish($p['type'])) throw new Exception('Немає прав');

            revokePunishment($pid, (int)$_SESSION['user_id']);
            echo json_encode(['ok' => true]);
            break;

        /* ─── Отримати покарання користувача ─── */
        case 'list':
            $userId = (int)($in['user_id'] ?? 0);
            if (!$userId) throw new Exception('Невірний ID');
            if (!canReviewAppeals() && !canPunish('warn')) {
                throw new Exception('Немає прав');
            }

            $list = getUserPunishmentsAll($userId);
            echo json_encode(['ok' => true, 'list' => $list]);
            break;

        default:
            throw new Exception('Невідома дія');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}