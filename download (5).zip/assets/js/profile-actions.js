'use strict';

(function(){
  const $ = s => document.querySelector(s);

  /* ═══════════════════════════════════════════════════════════
     МОДАЛКА МОДЕРАЦІЇ (видача покарань)
     ═══════════════════════════════════════════════════════════ */
  const openModBtn = $('[data-open-moderation]');
  const modModal = $('[data-modal="moderation"]');
  const punishForm = $('[data-punish-form]');

  if (openModBtn && modModal) {
    openModBtn.addEventListener('click', () => {
      modModal.classList.add('open');
      document.body.style.overflow = 'hidden';
      loadPunishments(parseInt(modModal.dataset.user));
    });
  }

  /* ─── Оновлення полів залежно від типу ─── */
  const typeRadios = modModal ? modModal.querySelectorAll('input[name="type"]') : [];
  const durationWrap = modModal ? modModal.querySelector('[data-duration-wrap]') : null;
  const reasonField = modModal ? modModal.querySelector('textarea[name="reason"]') : null;
  const previewEl = modModal ? modModal.querySelector('[data-punish-preview]') : null;

  function updatePunishPreview(){
    if (!previewEl || !modModal) return;
    const type = modModal.querySelector('input[name="type"]:checked')?.value || 'warn';
    const duration = parseInt(modModal.querySelector('select[name="duration"]')?.value || '0');
    const reason = reasonField ? reasonField.value.trim() : '';

    const typeLabel = { warn: 'Попередження', mute: 'Мут', ban: 'Бан' }[type];
    const typeClass = 'preview-' + type;

    let durationText = 'Назавжди';
    if (duration > 0) {
      if (duration < 24) durationText = duration + ' год';
      else if (duration < 24 * 30) durationText = Math.floor(duration / 24) + ' дн';
      else durationText = Math.floor(duration / (24 * 30)) + ' міс';
    }

    previewEl.innerHTML = `
      <div class="preview-header ${typeClass}">
        ${typeLabel}
      </div>
      <div class="preview-body">
        <div class="preview-row">
          <span>Причина:</span>
          <b>${reason ? escapeHtml(reason) : 'не вказана'}</b>
        </div>
        <div class="preview-row">
          <span>Термін:</span>
          <b>${type === 'warn' ? 'Постійно' : durationText}</b>
        </div>
      </div>
    `;
  }

  if (typeRadios.length) {
    typeRadios.forEach(r => r.addEventListener('change', () => {
      // Показуємо термін тільки для mute/ban
      if (durationWrap) {
        const type = modModal.querySelector('input[name="type"]:checked')?.value;
        durationWrap.style.display = (type === 'mute' || type === 'ban') ? 'block' : 'none';
      }
      updatePunishPreview();
    }));
  }

  if (reasonField) reasonField.addEventListener('input', updatePunishPreview);
  if (modModal) {
    const durSelect = modModal.querySelector('select[name="duration"]');
    if (durSelect) durSelect.addEventListener('change', updatePunishPreview);
  }

  /* ─── Завантаження покарань ─── */
  async function loadPunishments(userId){
    const list = modModal.querySelector('[data-punishments-list]');
    if (!list) return;
    list.innerHTML = '<div class="punish-loading">Завантаження...</div>';

    try {
      const res = await fetch(window.SITE_URL + '/api/punish.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'list', user_id: userId, csrf: window.CSRF })
      });
      const r = await res.json();
      if (r.ok) {
        list.innerHTML = '';
        if (!r.list.length) {
          list.innerHTML = '<div class="punish-empty">Немає покарань</div>';
          return;
        }
        r.list.forEach(p => {
          const el = document.createElement('div');
          el.className = 'punish-item ' + (p.is_active == 1 ? 'active' : 'inactive');
          const typeLabel = { warn: 'Попередження', mute: 'Мут', ban: 'Бан' }[p.type];
          const typeClass = 'punish-type-' + p.type;

          let durationText = 'Назавжди';
          if (p.expires_at) {
            durationText = 'до ' + p.expires_at;
          }

          el.innerHTML = `
            <div class="punish-item-head">
              <span class="punish-type ${typeClass}">${typeLabel}</span>
              <span class="punish-status ${p.is_active == 1 ? 'active' : 'inactive'}">
                ${p.is_active == 1 ? 'Активне' : 'Знято'}
              </span>
            </div>
            <div class="punish-item-reason">${escapeHtml(p.reason)}</div>
            <div class="punish-item-meta">
              <span>Видав: <b>${escapeHtml(p.issued_by_name || '—')}</b></span>
              <span>${durationText}</span>
              <span>${new Date(p.issued_at.replace(' ','T')).toLocaleString('uk-UA')}</span>
            </div>
            ${p.is_active == 1 ? `
              <button type="button" class="btn btn-ghost btn-sm punish-revoke" data-revoke="${p.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
                Зняти
              </button>
            ` : ''}
          `;
          list.appendChild(el);
        });

        list.querySelectorAll('[data-revoke]').forEach(btn => {
          btn.addEventListener('click', async () => {
            if (!confirm('Зняти покарання?')) return;
            btn.disabled = true;
            try {
              const res2 = await fetch(window.SITE_URL + '/api/punish.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  action: 'revoke',
                  punishment_id: parseInt(btn.dataset.revoke),
                  csrf: window.CSRF
                })
              });
              const r2 = await res2.json();
              if (r2.ok) {
                if (window.toast) window.toast('Покарання знято', 'success');
                loadPunishments(userId);
              } else {
                if (window.toast) window.toast(r2.error, 'error');
                btn.disabled = false;
              }
            } catch(e){ btn.disabled = false; }
          });
        });
      }
    } catch(e){
      list.innerHTML = '<div class="punish-empty error">Помилка завантаження</div>';
    }
  }

  /* ─── Видача покарання ─── */
  if (punishForm) {
    punishForm.addEventListener('submit', async e => {
      e.preventDefault();
      const data = new FormData(punishForm);
      const reason = (data.get('reason') || '').trim();
      const type = data.get('type');

      if (reason.length < 3) {
        if (window.toast) window.toast('Вкажіть причину (мін. 3 символи)', 'error');
        return;
      }

      const submitBtn = punishForm.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.innerHTML = '⏳ Видаємо...';

      try {
        const res = await fetch(window.SITE_URL + '/api/punish.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'issue',
            user_id: parseInt(data.get('user_id')),
            type: type,
            reason: reason,
            duration: parseInt(data.get('duration') || 0),
            csrf: data.get('csrf')
          })
        });
        const r = await res.json();
        if (r.ok) {
          if (window.toast) window.toast('Покарання видано ✅', 'success');
          punishForm.reset();
          updatePunishPreview();
          loadPunishments(parseInt(data.get('user_id')));
        } else {
          if (window.toast) window.toast(r.error, 'error');
        }
      } catch(e){
        if (window.toast) window.toast('Помилка мережі', 'error');
      }
      submitBtn.disabled = false;
      submitBtn.innerHTML = 'Видати покарання';
    });
  }

  /* ═══════════════════════════════════════════════════════════
     ПІДПИСКА
     ═══════════════════════════════════════════════════════════ */
  const subBtn = document.querySelector('[data-subscribe]');
  if (subBtn) {
    subBtn.addEventListener('click', async () => {
      try {
        const res = await fetch(window.SITE_URL + '/api/subscribe.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            user_id: parseInt(subBtn.dataset.subscribe),
            csrf: window.CSRF
          })
        });
        const r = await res.json();
        if (r.ok) {
          subBtn.classList.toggle('subscribed', r.subscribed);
          const t = subBtn.querySelector('[data-sub-text]');
          if (t) t.textContent = r.subscribed ? 'Ви підписані' : 'Підписатись';
          const count = document.querySelector('[data-sub-count]');
          if (count) count.textContent = r.count;
          if (window.toast) window.toast(r.subscribed ? 'Підписка оформлена' : 'Відписка', 'success', 2000);
        }
      } catch(e){}
    });
  }

  /* ═══════════════════════════════════════════════════════════
     ПРИВАТНІ ПОВІДОМЛЕННЯ (модалка)
     ═══════════════════════════════════════════════════════════ */
  const openDmBtn = document.querySelector('[data-open-dm]');
  const dmModal = document.querySelector('[data-modal="dm"]');
  if (openDmBtn && dmModal) {
    openDmBtn.addEventListener('click', async () => {
      dmModal.classList.add('open');
      document.body.style.overflow = 'hidden';
      const userId = parseInt(dmModal.dataset.user);

      const chat = dmModal.querySelector('[data-dm-chat]');
      const textarea = dmModal.querySelector('textarea');
      let dialogId = 0;
      let lastId = 0;
      let pollInterval = null;

      chat.innerHTML = '<div class="dm-loading">Завантаження...</div>';

      try {
        const r1 = await fetch(window.SITE_URL + '/api/dm.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'open', user_id: userId, csrf: window.CSRF })
        }).then(r => r.json());

        if (!r1.ok) throw new Error(r1.error);
        dialogId = r1.dialog_id;

        const head = dmModal.querySelector('[data-dm-name]');
        if (head) head.textContent = r1.other.username;

        async function loadMsgs(){
          const r2 = await fetch(window.SITE_URL + '/api/dm.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'messages', dialog_id: dialogId, since: lastId, csrf: window.CSRF })
          }).then(r => r.json());

          if (r2.ok) {
            if (lastId === 0) chat.innerHTML = '';
            r2.messages.forEach(m => {
              lastId = Math.max(lastId, m.id);
              const el = document.createElement('div');
              el.className = 'dm-msg ' + (m.is_mine ? 'mine' : 'theirs');
              el.innerHTML = `
                <div class="dm-msg-body">
                  <div class="dm-msg-text">${m.message}</div>
                  <div class="dm-msg-time">${m.time}</div>
                </div>
              `;
              chat.appendChild(el);
            });
            chat.scrollTop = chat.scrollHeight;
          }
        }

        await loadMsgs();
        pollInterval = setInterval(loadMsgs, 2000);

        const form = dmModal.querySelector('form');
        form.onsubmit = async e => {
          e.preventDefault();
          const msg = textarea.value.trim();
          if (!msg) return;
          textarea.value = '';
          await fetch(window.SITE_URL + '/api/dm.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'send', dialog_id: dialogId, message: msg, csrf: window.CSRF })
          });
          loadMsgs();
        };

        // Закриття → зупинка polling
        const observer = new MutationObserver(() => {
          if (!dmModal.classList.contains('open')) {
            if (pollInterval) clearInterval(pollInterval);
            observer.disconnect();
          }
        });
        observer.observe(dmModal, { attributes: true });

      } catch(e){
        chat.innerHTML = '<div class="dm-loading error">Помилка завантаження</div>';
      }
    });
  }

  /* ═══════════════════════════════════════════════════════════
     ЗАКРИТТЯ МОДАЛОК
     ═══════════════════════════════════════════════════════════ */
  document.querySelectorAll('[data-close-modal]').forEach(el => {
    el.addEventListener('click', () => {
      const m = el.closest('.user-modal');
      if (m) m.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  document.querySelectorAll('.user-modal').forEach(m => {
    m.addEventListener('click', e => {
      if (e.target === m) {
        m.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.user-modal.open').forEach(m => m.classList.remove('open'));
      document.body.style.overflow = '';
    }
  });

  function escapeHtml(s){
    return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
})();