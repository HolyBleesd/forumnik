'use strict';

(function(){
  const $ = id => document.getElementById(id);

  const modal       = $('roleModal');
  const delModal    = $('deleteRoleModal');
  const form        = $('roleForm');
  const actionField = $('roleAction');
  const idField     = $('roleId');
  const titleEl     = $('roleModalTitle');

  /* ─── Відкрити створення ─── */
  const openCreate = $('openCreateRole');
  if (openCreate) {
    openCreate.addEventListener('click', () => {
      titleEl.innerHTML = '🛡 Нова роль';
      actionField.value = 'create';
      idField.value = '';
      form.reset();
      $('roleColor').value = '#5b6ee1';
      $('roleColorValue').textContent = '#5b6ee1';
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
      setTimeout(() => $('roleName').focus(), 200);
    });
  }

  /* ─── Відкрити редагування ─── */
  document.querySelectorAll('[data-edit-role]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.editRole);
      const role = (window.ROLE_DATA || []).find(r => r.id === id);
      if (!role) return;

      titleEl.innerHTML = '✏️ Редагувати роль';
      actionField.value = 'update';
      idField.value = role.id;
      $('roleName').value = role.name;
      $('roleSlug').value = role.slug;
      $('roleColor').value = role.color;
      $('roleColorValue').textContent = role.color;
      $('roleSort').value = role.sort_order;
      $('roleDesc').value = role.description || '';

      // Дозволи
      document.querySelectorAll('[data-perm]').forEach(cb => {
        cb.checked = role.permissions.includes(cb.value);
      });

      // Системним — забороняємо міняти slug
      $('roleSlug').disabled = role.is_system === 1;
      $('roleName').disabled = role.is_system === 1;

      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  /* ─── Кнопки "Все"/"Нічого" ─── */
  document.querySelectorAll('[data-perm-all]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-perm]').forEach(cb => cb.checked = true);
    });
  });
  document.querySelectorAll('[data-perm-none]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-perm]').forEach(cb => cb.checked = false);
    });
  });

  /* ─── Видалити роль ─── */
  document.querySelectorAll('[data-delete-role]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.deleteRole;
      const role = (window.ROLE_DATA || []).find(r => r.id === parseInt(id));
      $('deleteRoleId').value = id;
      $('deleteRoleName').textContent = role ? role.name : '';
      delModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  /* ─── Закриття ─── */
  document.querySelectorAll('[data-close-modal]').forEach(el => {
    el.addEventListener('click', () => {
      el.closest('.role-modal').classList.remove('open');
      document.body.style.overflow = '';
      // reset disabled полів
      $('roleSlug').disabled = false;
      $('roleName').disabled = false;
    });
  });

  document.querySelectorAll('.role-modal').forEach(m => {
    m.addEventListener('click', e => {
      if (e.target === m) {
        m.classList.remove('open');
        document.body.style.overflow = '';
        $('roleSlug').disabled = false;
        $('roleName').disabled = false;
      }
    });
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.role-modal.open').forEach(m => {
        m.classList.remove('open');
        document.body.style.overflow = '';
        $('roleSlug').disabled = false;
        $('roleName').disabled = false;
      });
    }
  });

  /* ─── Колір → текст ─── */
  document.querySelectorAll('.color-input').forEach(inp => {
    inp.addEventListener('input', e => {
      const v = e.target.parentElement.querySelector('.color-value');
      if (v) v.textContent = e.target.value;
    });
  });
})();