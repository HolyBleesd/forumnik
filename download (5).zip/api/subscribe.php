<?php
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Не авторизовано']);
    exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
if (!checkCsrf($in['csrf'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF']);
    exit;
}

$targetId = (int)($in['user_id'] ?? 0);
if (!$targetId || $targetId === (int)$_SESSION['user_id']) {
    echo json_encode(['error' => 'Невірний ID']);
    exit;
}

$uid = (int)$_SESSION['user_id'];

if (isSubscribed($uid, $targetId)) {
    $pdo->prepare("DELETE FROM subscriptions WHERE follower_id = ? AND following_id = ?")
        ->execute([$uid, $targetId]);
    $subscribed = false;
} else {
    $pdo->prepare("INSERT INTO subscriptions (follower_id, following_id) VALUES (?,?)")
        ->execute([$uid, $targetId]);
    $subscribed = true;
    notify($targetId, 'sub', 'На вас підписались', SITE_URL . '/profile.php?id=' . $uid);
}

$count = getSubscribersCount($targetId);
echo json_encode(['ok' => true, 'subscribed' => $subscribed, 'count' => $count]);