<?php
require_once __DIR__ . '/../functions.php';
if (!canAccessAdmin()) redirect(SITE_URL);

$filterCat = (int)($_GET['cat'] ?? 0);

/* ═══════════ ОБРОБКА ═══════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && checkCsrf($_POST['csrf'] ?? '')) {
    $action = $_POST['action'] ?? '';
    
    try {
        /* ─── ПІДФОРУМИ ─── */
        if ($action === 'create') {
            $catId = (int)($_POST['category_id'] ?? 0);
            $parentId = (int)($_POST['parent_id'] ?? 0) ?: null;
            $name = trim($_POST['name'] ?? '');
            if (!$catId || $name === '') throw new Exception('Заповніть поля');
            
            $depth = 1;
            if ($parentId) {
                $stmt = $pdo->prepare("SELECT depth FROM subforums WHERE id = ?");
                $stmt->execute([$parentId]);
                $p = $stmt->fetch();
                if ($p) $depth = (int)$p['depth'] + 1;
            }
            
            $isHidden = isset($_POST['is_hidden']) ? 1 : 0;
            
            $stmt = $pdo->prepare("INSERT INTO subforums (category_id, parent_id, name, description, icon, color, sort_order, depth, is_hidden) VALUES (?,?,?,?,?,?,?,?,?)");
            $stmt->execute([
                $catId, $parentId, $name,
                trim($_POST['description'] ?? ''),
                trim($_POST['icon'] ?? 'hash'),
                $_POST['color'] ?? '#5b6ee1',
                (int)($_POST['sort_order'] ?? 0),
                $depth,
                $isHidden
            ]);
            $sfId = (int)$pdo->lastInsertId();
            
            flash('Підфорум створено (ID: ' . $sfId . ')', 'success');
            
        } elseif ($action === 'update') {
            $id = (int)$_POST['id'];
            
            $stmt = $pdo->prepare("UPDATE subforums SET name=?, description=?, icon=?, color=?, sort_order=?, is_hidden=? WHERE id=?");
            $stmt->execute([
                trim($_POST['name']),
                trim($_POST['description'] ?? ''),
                trim($_POST['icon'] ?? 'hash'),
                $_POST['color'] ?? '#5b6ee1',
                (int)($_POST['sort_order'] ?? 0),
                isset($_POST['is_hidden']) ? 1 : 0,
                $id
            ]);
            
            flash('Підфорум оновлено', 'success');
            
        } elseif ($action === 'delete') {
            $id = (int)$_POST['id'];
            $pdo->prepare("DELETE FROM subforums WHERE id = ?")->execute([$id]);
            flash('Підфорум видалено', 'success');
            
        /* ─── СТАРІ ПІДКАТЕГОРІЇ ─── */
        } elseif ($action === 'create_sub') {
            $catId = (int)$_POST['category_id'];
            $name = trim($_POST['name'] ?? '');
            if (!$catId || $name === '') throw new Exception('Заповніть поля');
            
            $stmt = $pdo->prepare("INSERT INTO subcategories (category_id,name,description,icon,color,sort_order) VALUES (?,?,?,?,?,?)");
            $stmt->execute([
                $catId, $name,
                trim($_POST['description'] ?? ''),
                trim($_POST['icon']) ?: 'hash',
                $_POST['color'] ?? '#5b6ee1',
                (int)($_POST['sort_order'] ?? 0)
            ]);
            flash('Підкатегорію створено', 'success');
            
        } elseif ($action === 'update_sub') {
            $id = (int)$_POST['id'];
            
            $stmt = $pdo->prepare("UPDATE subcategories SET name=?,description=?,icon=?,color=?,sort_order=?,is_hidden=? WHERE id=?");
            $stmt->execute([
                trim($_POST['name']),
                trim($_POST['description'] ?? ''),
                trim($_POST['icon']) ?: 'hash',
                $_POST['color'] ?? '#5b6ee1',
                (int)($_POST['sort_order'] ?? 0),
                isset($_POST['is_hidden']) ? 1 : 0,
                $id
            ]);
            flash('Підкатегорію оновлено', 'success');
            
        } elseif ($action === 'delete_sub') {
            $id = (int)$_POST['id'];
            $pdo->prepare("DELETE FROM subcategories WHERE id=?")->execute([$id]);
            flash('Підкатегорію видалено', 'success');
        }
    } catch (Exception $e) {
        flash($e->getMessage(), 'error');
    }
    
    redirect(SITE_URL . '/admin/subforums.php' . ($filterCat ? '?cat=' . $filterCat : ''));
}

/* ═══════════ ДАНІ (всі у try/catch) ═══════════ */
$cats = [];
try {
    $cats = $pdo->query("SELECT * FROM categories ORDER BY sort_order")->fetchAll();
} catch (Exception $e) {}

$allSubforums = [];
try {
    $allSubforums = $pdo->query("SELECT * FROM subforums ORDER BY category_id, sort_order, id")->fetchAll();
} catch (Exception $e) {}

$allSubcats = [];
try {
    $allSubcats = $pdo->query("SELECT * FROM subcategories ORDER BY category_id, sort_order, id")->fetchAll();
} catch (Exception $e) {}

/* Статистика тем (спрощено) */
$topicCounts = [];
try {
    $rows = $pdo->query("SELECT subforum_id, COUNT(*) AS cnt FROM topics WHERE subforum_id IS NOT NULL AND is_deleted=0 GROUP BY subforum_id")->fetchAll();
    foreach ($rows as $r) {
        $topicCounts[(int)$r['subforum_id']] = (int)$r['cnt'];
    }
} catch (Exception $e) {}

/* Дерево */
$byCat = [];
foreach ($cats as $c) {
    $catItems = array_values(array_filter($allSubforums, fn($s) => (int)$s['category_id'] === (int)$c['id']));
    $byCat[$c['id']] = buildSubforumTree($catItems, null);
}

$subcatsByCat = [];
foreach ($allSubcats as $s) {
    $subcatsByCat[$s['category_id']][] = $s;
}

$iconList = [
    'message','monitor','gamepad','music','dice','bulb','flame','star','heart',
    'palette','camera','film','book','award','globe','bug','folder','hash','grid',
    'user','users','shield','bell','file-text','pin','eye','zap','sparkle','settings','chart','trend'
];

$pageTitle = 'Підфоруми';
require __DIR__ . '/../header.php';
?>

<div class="breadcrumbs">
  <a href="<?= SITE_URL ?>"><?= icon('home', 12) ?> Головна</a>
  <span class="sep">/</span>
  <a href="<?= SITE_URL ?>/admin/index.php">Адмінка</a>
  <span class="sep">/</span>
  <span class="current">Підфоруми</span>
</div>

<div class="section-head">
  <h1 class="section-title"><?= icon('grid', 18) ?> Підфоруми та підкатегорії</h1>
</div>

<div class="admin-nav">
  <a href="<?= SITE_URL ?>/admin/index.php"><?= icon('chart', 14) ?> Дашборд</a>
  <a href="<?= SITE_URL ?>/admin/users.php"><?= icon('users', 14) ?> Користувачі</a>
  <a href="<?= SITE_URL ?>/admin/categories.php"><?= icon('folder', 14) ?> Категорії</a>
  <a href="<?= SITE_URL ?>/admin/subforums.php" class="active"><?= icon('grid', 14) ?> Підфоруми</a>
  <a href="<?= SITE_URL ?>/admin/topics.php"><?= icon('file-text', 14) ?> Теми</a>
  <a href="<?= SITE_URL ?>/admin/roles.php"><?= icon('shield', 14) ?> Ролі</a>
  <a href="<?= SITE_URL ?>/admin/settings.php"><?= icon('settings', 14) ?> Налаштування</a>
</div>

<?php foreach ($cats as $c): 
    if ($filterCat && $filterCat !== (int)$c['id']) continue;
    $tree = $byCat[$c['id']] ?? [];
    $subs = $subcatsByCat[$c['id']] ?? [];
?>
  <div class="cat-tree-item" style="--tint: <?= e($c['color']) ?>; margin-bottom:16px">
    <div class="cat-tree-head">
      <div class="cat-tree-ico"><?= icon($c['icon'] ?: 'hash', 20) ?></div>
      <div class="cat-tree-info">
        <div class="cat-tree-name"><?= e($c['name']) ?></div>
        <div class="cat-tree-meta">Категорія #<?= (int)$c['id'] ?></div>
      </div>
      <div class="cat-tree-actions">
        <button type="button" class="cat-act-btn primary" data-add-parent="<?= $c['id'] ?>">
          <?= icon('plus', 13) ?> Підфорум
        </button>
        <button type="button" class="cat-act-btn" data-add-sub="<?= $c['id'] ?>">
          <?= icon('plus', 13) ?> Підкатегорія
        </button>
      </div>
    </div>
    
    <?php if ($tree): ?>
      <div class="cat-tree-subs">
        <div class="perm-group-label" style="margin:8px 0 6px">ПІДФОРУМИ</div>
        <?php renderSubforumTree($tree, (int)$c['id'], $topicCounts); ?>
      </div>
    <?php endif; ?>
    
    <?php if ($subs): ?>
      <div class="cat-tree-subs">
        <div class="perm-group-label" style="margin:8px 0 6px">ПІДКАТЕГОРІЇ (старі)</div>
        <?php foreach ($subs as $s): ?>
          <div class="cat-sub-item" style="--sub-tint: <?= e($s['color']) ?>">
            <div class="cat-sub-ico"><?= icon($s['icon'] ?: 'hash', 15) ?></div>
            <div class="cat-sub-info">
              <div class="cat-sub-name">
                <?= e($s['name']) ?>
                <?php if ($s['is_hidden']): ?>
                  <span class="cat-sub-badge hidden"><?= icon('lock', 10) ?></span>
                <?php endif; ?>
              </div>
              <div class="cat-sub-meta">Підкатегорія #<?= (int)$s['id'] ?></div>
            </div>
            <div class="cat-sub-actions">
              <button type="button" class="cat-act-btn" data-edit-sub="<?= $s['id'] ?>">
                <?= icon('edit', 12) ?>
              </button>
              <form method="post" class="cat-act-form" onsubmit="return confirm('Видалити підкатегорію?')">
                <input type="hidden" name="csrf" value="<?= csrf() ?>">
                <input type="hidden" name="action" value="delete_sub">
                <input type="hidden" name="id" value="<?= $s['id'] ?>">
                <button type="submit" class="cat-act-btn danger"><?= icon('trash', 12) ?></button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    
    <?php if (!$tree && !$subs): ?>
      <div class="cat-tree-subs">
        <div style="padding:16px;text-align:center;color:var(--txt-3);font-size:12px">
          Ще немає підфорумів чи підкатегорій
        </div>
      </div>
    <?php endif; ?>
  </div>
<?php endforeach; ?>

<?php
function renderSubforumTree(array $nodes, int $categoryId, array $topicCounts, int $depth = 0) {
    foreach ($nodes as $n) {
        $indent = str_repeat('— ', $depth);
        $hasChildren = !empty($n['children']);
        $tCount = $topicCounts[(int)$n['id']] ?? 0;
        ?>
        <div class="cat-sub-item" style="--sub-tint: <?= e($n['color']) ?>; margin-left: <?= $depth * 20 ?>px">
          <div class="cat-sub-ico"><?= icon($n['icon'] ?: 'hash', 15) ?></div>
          <div class="cat-sub-info">
            <div class="cat-sub-name">
              <?= $indent ?><?= e($n['name']) ?>
              <?php if ($n['is_hidden']): ?>
                <span class="cat-sub-badge hidden"><?= icon('lock', 10) ?></span>
              <?php endif; ?>
            </div>
            <div class="cat-sub-meta">
              <?= icon('file-text', 10) ?> <?= $tCount ?> тем
              · ID #<?= (int)$n['id'] ?>
              <?php if ($hasChildren): ?>
                · <?= count($n['children']) ?> вкладених
              <?php endif; ?>
            </div>
          </div>
          <div class="cat-sub-actions">
            <a href="<?= SITE_URL ?>/subforum.php?id=<?= $n['id'] ?>" target="_blank" class="cat-act-btn" title="Відкрити">
              <?= icon('eye', 12) ?>
            </a>
            <button type="button" class="cat-act-btn" data-add-child="<?= $n['id'] ?>" data-cat="<?= $categoryId ?>" title="Додати вкладений">
              <?= icon('plus', 12) ?>
            </button>
            <button type="button" class="cat-act-btn" data-edit="<?= $n['id'] ?>" title="Редагувати">
              <?= icon('edit', 12) ?>
            </button>
            <form method="post" class="cat-act-form" onsubmit="return confirm('Видалити підфорум?')">
              <input type="hidden" name="csrf" value="<?= csrf() ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= $n['id'] ?>">
              <button type="submit" class="cat-act-btn danger"><?= icon('trash', 12) ?></button>
            </form>
          </div>
        </div>
        <?php
        if ($hasChildren) renderSubforumTree($n['children'], $categoryId, $topicCounts, $depth + 1);
    }
}
?>

<!-- МОДАЛКА ПІДФОРУМУ -->
<div class="role-modal" id="subforumModal">
  <div class="role-modal-box role-modal-box-lg">
    <div class="role-modal-head">
      <h3 id="modalTitle"><?= icon('grid', 16) ?> Підфорум</h3>
      <button type="button" class="role-modal-close" data-close-modal><?= icon('x', 16) ?></button>
    </div>

    <form method="post" class="role-modal-form" id="sfForm">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="action" id="sfAction" value="create">
      <input type="hidden" name="id" id="sfId">
      <input type="hidden" name="category_id" id="sfCatId">
      <input type="hidden" name="parent_id" id="sfParentId">

      <div class="role-modal-row">
        <label>Назва<input type="text" name="name" id="sfName" required></label>
        <label>Порядок<input type="number" name="sort_order" id="sfSort" value="0"></label>
      </div>

      <label>Опис<input type="text" name="description" id="sfDesc"></label>

      <label>Колір
        <div class="color-input-wrap">
          <input type="color" name="color" id="sfColor" value="#5b6ee1" class="color-input">
          <span class="color-value">#5b6ee1</span>
        </div>
      </label>

      <div class="form-group">
        <span class="form-label">Іконка</span>
        <div class="icon-picker">
          <?php foreach ($iconList as $ic): ?>
            <label class="icon-picker-item">
              <input type="radio" name="icon" value="<?= $ic ?>">
              <span class="icon-picker-box"><?= icon($ic, 18) ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <label class="cat-checkbox"><input type="checkbox" name="is_hidden" id="sfHidden"> Приховати</label>

      <div class="role-modal-actions">
        <button type="button" class="btn btn-ghost" data-close-modal>Скасувати</button>
        <button type="submit" class="btn btn-primary"><?= icon('check', 15) ?> Зберегти</button>
      </div>
    </form>
  </div>
</div>

<!-- МОДАЛКА ПІДКАТЕГОРІЇ -->
<div class="role-modal" id="subcatModal">
  <div class="role-modal-box">
    <div class="role-modal-head">
      <h3 id="subcatTitle"><?= icon('hash', 16) ?> Підкатегорія</h3>
      <button type="button" class="role-modal-close" data-close-modal><?= icon('x', 16) ?></button>
    </div>

    <form method="post" class="role-modal-form" id="subcatForm">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="action" id="subcatAction" value="create_sub">
      <input type="hidden" name="id" id="subcatId">
      <input type="hidden" name="category_id" id="subcatCatId">

      <div class="role-modal-row">
        <label>Назва<input type="text" name="name" id="subcatName" required></label>
        <label>Порядок<input type="number" name="sort_order" id="subcatSort" value="0"></label>
      </div>

      <label>Опис<input type="text" name="description" id="subcatDesc"></label>

      <label>Колір
        <div class="color-input-wrap">
          <input type="color" name="color" id="subcatColor" value="#5b6ee1" class="color-input">
          <span class="color-value">#5b6ee1</span>
        </div>
      </label>

      <label class="cat-checkbox"><input type="checkbox" name="is_hidden" id="subcatHidden"> Приховати</label>

      <div class="role-modal-actions">
        <button type="button" class="btn btn-ghost" data-close-modal>Скасувати</button>
        <button type="submit" class="btn btn-primary"><?= icon('check', 15) ?> Зберегти</button>
      </div>
    </form>
  </div>
</div>

<script>
window.SUBFORUMS = <?= json_encode(array_map(function($s) {
    return [
        'id' => (int)$s['id'],
        'category_id' => (int)$s['category_id'],
        'parent_id' => (int)($s['parent_id'] ?? 0),
        'name' => $s['name'],
        'description' => $s['description'],
        'icon' => $s['icon'],
        'color' => $s['color'],
        'sort_order' => (int)$s['sort_order'],
        'is_hidden' => (int)$s['is_hidden'],
    ];
}, $allSubforums)) ?>;

window.SUBCATS = <?= json_encode(array_map(function($s) {
    return [
        'id' => (int)$s['id'],
        'category_id' => (int)$s['category_id'],
        'name' => $s['name'],
        'description' => $s['description'],
        'icon' => $s['icon'],
        'color' => $s['color'],
        'sort_order' => (int)$s['sort_order'],
        'is_hidden' => (int)$s['is_hidden'],
    ];
}, $allSubcats)) ?>;

(function(){
  const $ = id => document.getElementById(id);
  const sfModal = $('subforumModal');
  const sfForm = $('sfForm');
  const subcatModal = $('subcatModal');
  const subcatForm = $('subcatForm');

  document.querySelectorAll('[data-add-parent]').forEach(btn => {
    btn.addEventListener('click', () => {
      $('modalTitle').innerHTML = '📁 Новий підфорум';
      $('sfAction').value = 'create';
      $('sfId').value = '';
      $('sfCatId').value = btn.dataset.addParent;
      $('sfParentId').value = '';
      sfForm.reset();
      $('sfColor').value = '#5b6ee1';
      sfModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  document.querySelectorAll('[data-add-child]').forEach(btn => {
    btn.addEventListener('click', () => {
      $('modalTitle').innerHTML = '📁 Вкладений підфорум';
      $('sfAction').value = 'create';
      $('sfId').value = '';
      $('sfCatId').value = btn.dataset.cat;
      $('sfParentId').value = btn.dataset.addChild;
      sfForm.reset();
      $('sfColor').value = '#5b6ee1';
      sfModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  document.querySelectorAll('[data-edit]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.edit);
      const sf = (window.SUBFORUMS || []).find(s => s.id === id);
      if (!sf) return;
      
      $('modalTitle').innerHTML = '✏️ Редагувати';
      $('sfAction').value = 'update';
      $('sfId').value = sf.id;
      $('sfCatId').value = sf.category_id;
      $('sfParentId').value = sf.parent_id || '';
      $('sfName').value = sf.name;
      $('sfDesc').value = sf.description || '';
      $('sfColor').value = sf.color;
      $('sfSort').value = sf.sort_order;
      $('sfHidden').checked = sf.is_hidden === 1;
      
      sfForm.querySelectorAll('input[name="icon"]').forEach(inp => {
        inp.checked = inp.value === sf.icon;
      });
      
      sfModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  document.querySelectorAll('[data-add-sub]').forEach(btn => {
    btn.addEventListener('click', () => {
      $('subcatTitle').innerHTML = '🏷 Нова підкатегорія';
      $('subcatAction').value = 'create_sub';
      $('subcatId').value = '';
      $('subcatCatId').value = btn.dataset.addSub;
      subcatForm.reset();
      $('subcatColor').value = '#5b6ee1';
      subcatModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  document.querySelectorAll('[data-edit-sub]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.editSub);
      const sc = (window.SUBCATS || []).find(s => s.id === id);
      if (!sc) return;
      
      $('subcatTitle').innerHTML = '✏️ Редагувати';
      $('subcatAction').value = 'update_sub';
      $('subcatId').value = sc.id;
      $('subcatCatId').value = sc.category_id;
      $('subcatName').value = sc.name;
      $('subcatDesc').value = sc.description || '';
      $('subcatColor').value = sc.color;
      $('subcatSort').value = sc.sort_order;
      $('subcatHidden').checked = sc.is_hidden === 1;
      
      subcatModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  document.querySelectorAll('[data-close-modal]').forEach(el => {
    el.addEventListener('click', () => {
      el.closest('.role-modal').classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  document.querySelectorAll('.role-modal').forEach(m => {
    m.addEventListener('click', e => {
      if (e.target === m) {
        m.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.role-modal.open').forEach(m => {
        m.classList.remove('open');
        document.body.style.overflow = '';
      });
    }
  });
})();
</script>

<?php require __DIR__ . '/../footer.php'; ?>